# CLAUDE.md

> **対象読者**: AI（Claude Code）向け
> **用途**: 絶対ルール（全タスクで必ず従うべき原則）
> **詳細版**: @docs-private/frameworks/*.md
>
> This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Core Rules
@~/.claude/CLAUDE.md

## Project Information
@docs/PROJECT_INFO.md

## Common Commands
@docs/COMMANDS.md

## Current Development Status
@docs-private/PROJECT_STATUS.md

**📝 ドキュメント依存関係**:
このドキュメントを更新した場合、以下も確認してください:
- @docs-private/frameworks/タスク実行プロトコル.md（詳細手順を確認）
- @docs-private/frameworks/品質ゲート定義.md（完了基準との整合性）
- @docs-private/RULES.md（運用ルールとの整合性）

---

## アーキテクチャ

### kits/ ディレクトリ（最重要）

再利用可能な共通部品の集合。すべてのコードは「他のプロジェクトでも使える」ことを前提に設計する。

- **kits.accounts**: ユーザー・グループ・権限管理、テストユーザー生成
- **kits.demos**: `DemoRequest`モデル（申請・承認フローの参考実装）
- **kits.approvals**: 承認フロー・状態遷移（django-fsm使用）
- **kits.audit**: 変更履歴追跡（django-simple-history使用）

詳細: @docs/kits/README.md

### 推奨パターン

- **状態遷移**: django-fsm + transaction.atomic
- **履歴管理**: django-simple-history
- **権限管理**: Django標準のPermission + Group
- **非同期処理**: Celery タスク

### 新機能実装時の参考

新しいモデル実装時は `kits/demos/models.py` の `DemoRequest` クラスを参照。django-fsmによる状態管理の実装例が含まれる。

## コード原則

1. **再利用性**: すべてのコードは他のプロジェクトでも使えるように設計
2. **説明可能性**: コードを読んだ人が「なぜこう書いたのか」を理解できる
3. **運用可能性**: 本番環境を意識（エラーハンドリング、ログ出力）

## 命名規則

- **アプリ名**: `kits.<機能名>`（例：kits.approvals）
- **モデル名**: PascalCase（例：DemoRequest）
- **関数・変数**: snake_case
- **定数**: UPPER_SNAKE_CASE

---

## タスク実行の絶対ルール（Learning-Driven Development）

### 全タスク共通の必須プロセス

**全てのタスクで以下のドキュメントを必ず参照**:

1. **タスク実行プロトコル**: @docs-private/frameworks/タスク実行プロトコル.md
   - タスク開始から完了までの標準手順
   - 4つのPhase（開始 → 実装 → 品質確認 → 学習記録）

2. **品質ゲート定義**: @docs-private/frameworks/品質ゲート定義.md
   - タスク完了の明確な基準
   - タスク種別ごとのチェック項目

3. **5段階理解モデル**: @docs-private/frameworks/5段階理解モデル.md
   - 学習の深さのフレームワーク
   - MVP期間はレベル3到達が目標

### タスク開始時（Phase 1）- 必須

1. **プロトコル確認**
   - タスク実行プロトコルを参照
   - 品質ゲートを確認

2. **TodoWriteに4つのPhaseを自動登録** ← **🚨 NEW: 自動化**
   タスク開始時、AIは**自動的に**以下をTodoWriteに登録:
   ```
   [ ] MVP-X Phase 1: タスク理解と準備
   [ ] MVP-X Phase 2: 実装
   [ ] MVP-X Phase 3: 品質確認
   [ ] MVP-X Phase 4: 学習ログ作成 ← **絶対にスキップ不可**
   ```

   **重要**: これを忘れるとPhase 4スキップの原因になる。
   **必ず実行**: TodoWriteツールを使用して4つ全て登録すること。

3. **チェックリスト登録**
   - 品質ゲートの項目をTodoWriteに登録
   - 実行状況を可視化

4. **学習環境準備**
   - 学習ログファイルを作成（Phase 4で使用）
   - 設計判断記録の準備

5. **ユーザー確認**
   - 実行計画を提示
   - ユーザーの承認を待つ（絶対に勝手に進めない）

### Phase間の移行ルール（NEW）

**次のPhaseに進む条件**: 前のPhaseがTodoWriteで completed であること

例:
- Phase 2に進む前 → Phase 1が completed であることを確認
- Phase 3に進む前 → Phase 2が completed であることを確認
- Phase 4に進む前 → Phase 3が completed であることを確認
- 次タスクに進む前 → Phase 4が completed であることを確認

**チェック方法**: TodoWriteの状態を確認してから次に進む

### 実装中（Phase 2）- 推奨

1. **設計判断の記録**
   - 重要な判断は必ず記録
   - テンプレート: @docs-private/frameworks/設計判断記録テンプレート.md

2. **エラー解決の記録**
   - 5ステップ解決法を適用
   - テンプレート: @docs-private/frameworks/よくある間違い集テンプレート.md

3. **学習メモ**
   - 実装しながら箇条書きでメモ
   - 後で学習ログに統合

### 完了前（Phase 3）- 必須

1. **品質ゲート確認**
   - 全項目をチェック
   - 全てYESでなければ未完了

2. **コード品質チェック**
   - Linter/Formatter実行
   - テスト実行
   - コード品質3原則確認

### 完了時（Phase 4）- 必須 ⚠️ **絶対にスキップ禁止**

**🚨 重要**: このPhaseをスキップすると、プロジェクトの目的「最高の教材作成」を達成できません。

1. **学習ログ完成**
   - 5段階理解モデルでレベル3到達
   - 設計判断を記録
   - エラー解決を記録
   - ⚠️ 学習ログなしでタスク完了とは呼ばない

2. **TodoWrite更新**
   - 完了タスクをcompletedにマーク
   - 次タスクを登録

3. **ユーザー報告**
   - 完了内容を報告
   - 次タスクを提案 → 承認を待つ

**タスク完了の定義**:
- Phase 1-4 **全て** 完了して初めて「タスク完了」
- Phase 3まで完了 = 「実装完了」であって「タスク完了」ではない
- 学習ログ作成は **必須**、任意ではない

### 学習目標（Phase別）

**MVP期間（現在）**:
- 必須: レベル1-3（What, How, Why）
- 時間: 学習記録に40分/タスク（全体の約25%）

**MLP期間**:
- 必須: レベル1-4（Think）
- 時間: 学習記録に50分/タスク

**MAP期間**:
- 必須: レベル1-5（Transfer）
- 時間: 学習記録に80分/タスク

### 禁止事項（絶対に守る）

- ❌ プロトコルを参照せずにタスク開始
- ❌ 品質ゲートを確認せずに完了報告
- ❌ **学習ログを書かずに次タスクへ** ← **🚨 最重要**
- ❌ ユーザー承認なしで連続実行
- ❌ 設計判断の記録を省略
- ❌ Phase 4（学習記録）をスキップ ← **🚨 絶対禁止**

### 撤退基準

以下の場合は一時停止してユーザーに相談:
- 予定時間の150%を超過
- 同じエラーで30分以上悩んでいる
- 品質ゲートをクリアできない

---

## 参考ドキュメント（AI向け）

### フレームワーク
- タスク実行プロトコル: @docs-private/frameworks/タスク実行プロトコル.md
- 品質ゲート定義: @docs-private/frameworks/品質ゲート定義.md
- 5段階理解モデル: @docs-private/frameworks/5段階理解モデル.md
- よくある間違い集テンプレート: @docs-private/frameworks/よくある間違い集テンプレート.md
- 設計判断記録テンプレート: @docs-private/frameworks/設計判断記録テンプレート.md
- レビューチェックリスト: @docs-private/frameworks/レビューチェックリスト.md
- ブロッカー報告テンプレート: @docs-private/frameworks/ブロッカー報告テンプレート.md

### テンプレート
- 学習ログテンプレート: @docs-private/daily_logs/学習ログテンプレート.md

### 教育資料
- 教育資料作成ルール: @docs-private/frameworks/教育資料作成ルール.md
