# 🤖 AIアシスタント向け プロジェクト概要

> **このファイルの目的**
>
> 新しいAIセッションやチャット切り替え時に、このファイルを最初に読み込むことで、プロジェクト全体の構造と現在の状況を即座に理解できます。

---

## 🎯 プロジェクトの本質（30秒で理解）

### 何を作っているか
**業務Webアプリケーションの共通基盤（labapp）** を開発し、インターンシップの技術課題で**30分以内に動く業務アプリ**を実現する。

### なぜ作っているか
過去のインターンシップ課題4つを分析した結果、**70%以上の共通パターン**が存在することが判明。これらを**kitsパッケージ**として実装することで、課題実装時間を大幅に短縮できる。

### 現在の状況（2025-10-06時点）
- ✅ **Tier 1完全完了**: notifications(100%), reports(100%), io(100%), approvals(100%), audit(100%)
- ✅ **コード品質100%**: Pylanceエラー0件、Ruff All checks passed
- ✅ **VS Code環境最適化**: 拡張機能整理、Black Formatter統一
- ✅ **管理画面日本語化**: kits全アプリ＋サードパーティアプリを実務的な名前に統一
- 📅 **インターンシップ**: 2025年10月6日から（3週間、100時間）
- 🎯 **新戦略策定済み**: MVP→MLP→MAP段階的進化戦略

---

## 📁 重要ファイルへのクイックアクセス

### 必読ドキュメント（優先順）

1. **[インターンシップ戦略.md](/home/hirok/work/school_diary/docs-private/インターンシップ戦略.md)**
   - 🎯 100時間の戦略と時間配分、完了済みTier 1の状況

2. **[プロジェクトテンプレート化ガイド.md](/home/hirok/work/school_diary/docs-private/プロジェクトテンプレート化ガイド.md)**
   - 🚀 create_project.shで3秒プロジェクト作成

3. **[ARCHITECTURE.md](/home/hirok/work/school_diary/docs-private/ARCHITECTURE.md)**
   - 🏗️ 設計判断の記録（VS Code最適化、Pylance型チェック戦略）

4. **[情報管理ガイド_AI向け.md](/home/hirok/work/school_diary/docs-private/情報管理ガイド_AI向け.md)**
   - 📋 新スレッド開始時の標準手順

### kitsパッケージドキュメント（完成済み）

| 機能 | ドキュメントパス | 状態 |
|-----|----------------|------|
| **通知機能** | [kits/notifications/](/home/hirok/work/labapp/docs/kits/notifications/) | ✅ 100% |
| **レポート機能** | [kits/reports/](/home/hirok/work/labapp/docs/kits/reports/) | ✅ 100% |
| **データI/O** | [kits/io/](/home/hirok/work/labapp/docs/kits/io/) | ✅ 100% |
| **承認フロー** | [kits/approvals/](/home/hirok/work/labapp/docs/kits/approvals/) | ✅ 100% |
| **監査証跡** | [kits/audit/](/home/hirok/work/labapp/docs/kits/audit/) | ✅ 100% |

---

## 🏗️ プロジェクト構造

```
/home/hirok/work/
├── labapp/                 # メインプロジェクト
│   ├── kits/              # 再利用可能パッケージ（Tier 1完了）
│   │   ├── accounts/      ✅ 100%
│   │   ├── approvals/     ✅ 100%
│   │   ├── audit/         ✅ 100%
│   │   ├── demos/         ✅ 100%
│   │   ├── notifications/ ✅ 100%
│   │   ├── reports/       ✅ 100%
│   │   └── io/            ✅ 100%
│   │
│   ├── config/            # Django設定
│   ├── docs/              # 実装ドキュメント
│   │   └── kits/         # kitsドキュメント（初心者向け）
│   └── requirements/      # 依存パッケージ
│
├── docs/                   # 戦略ドキュメント
│   ├── README_AI向け.md   # このファイル
│   ├── インターンシップ戦略.md
│   ├── プロジェクトテンプレート化ガイド.md
│   ├── ARCHITECTURE.md
│   └── 情報管理ガイド_AI向け.md
│
└── create_project.sh       # プロジェクト生成スクリプト（3秒）
```

---

## 🔧 環境構成の重要ポイント

### よくある誤解の解消
- ❌ **誤**: 「開発環境はDockerを使う」
- ✅ **正**: 「コード編集はローカル、実行環境はDockerを使う」

### 環境の役割
- **ローカル（WSL2）**: VS Codeでコード編集、Git操作
- **Docker**: PostgreSQL、Django、Celery等の実行環境
- **本番（EC2）**: Dockerなし、直接実行

### 開発フロー
1. VS Codeでコード編集（ローカル）
2. `docker-compose up`で実行（Docker）
3. ブラウザで動作確認（http://localhost:8000）

---

## 💡 AIアシスタントへの指示

### ユーザーサポート時の確認事項

1. **実装作業の場合**
   - [ ] 対象のkitsパッケージは？（notifications, reports, io）
   - [ ] 実装ガイドを参照しているか？
   - [ ] demosパターンを踏襲しているか？

2. **設計相談の場合**
   - [ ] KITS_CONTEXT.mdの設計方針に沿っているか？
   - [ ] 疎結合の原則を守っているか？
   - [ ] テスタビリティを考慮しているか？

3. **トラブルシューティングの場合**
   - [ ] 各実装ガイドのトラブルシューティング項を確認
   - [ ] 依存関係は正しくインストールされているか？
   - [ ] Django設定は正しいか？

### コード生成時の原則

```python
# ✅ 良い例: 疎結合・汎用的
class NotificationService:
    def create_from_template(self, template_code: str, recipient: User, context: dict):
        pass

# ❌ 悪い例: 特定アプリに依存
from apps.overtime.models import OvertimeRequest
class NotificationService:
    def send_overtime_notification(self, request: OvertimeRequest):
        pass
```

### ファイル配置のルール

- **kitsパッケージ本体**: `/home/hirok/work/labapp/kits/`
- **テンプレート**: `/home/hirok/work/labapp/templates/`
- **テスト**: `/home/hirok/work/labapp/tests/`
- **ドキュメント**: `/home/hirok/work/labapp/docs/` または `/home/hirok/work/school_diary/docs-private/`

---

## 🚨 重要な制約事項

### 技術スタック（変更不可）
- Python 3.12
- Django 5.1.12
- PostgreSQL（必須）
- Celery（非同期処理）

### 設計方針（厳守）
- **サブディレクトリ最小限**: templatetags/とmanagement/commands/のみ
- **demosパターン踏襲**: 既存の成功パターンに従う
- **疎結合原則**: 他アプリに依存しない
- **テストカバレッジ**: 80%以上

### パフォーマンス目標
- プロジェクト生成: 3秒以内
- 環境構築: 30分以内
- 通知送信: 1000件/10分
- レポート生成: 10000行/30秒

---

## 📊 インターンシップ戦略（2025-10-06時点）

### ✅ 完了済みの準備
- **基盤構築100%完了**: 全kitsパッケージが本番レベル
- **3秒プロジェクト生成**: create_project.shスクリプト完備
- **管理画面だけで1-6時間実装**: DemoRequestコピーで即対応

### 🎯 MVP → MLP → MAP 戦略
```
Day 1 AM: MVP（管理画面）      = 60点保証
Day 1-2:  MLP（Bootstrap UI）  = 75点達成
Day 3:    MAP（最適化）        = 85点以上
Day 4:    AWS環境              = 95点狙い
```

### 📊 課題対応可能性
| 課題 | 管理画面のみ | カスタムUI | 必要時間 |
|-----|------------|-----------|---------|
| 残業管理 | 95% | 98% | 1-2時間 |
| 母子手帳 | 80% | 90% | 3-5時間 |
| 野球部 | 90% | 95% | 3-5時間 |
| 図書館 | 85% | 92% | 4-6時間 |

### 🚀 技術スタック決定
- **必須**: Django + Bootstrap 5 + PostgreSQL
- **オプション**: HTMX（部分更新）、Alpine.js（軽量JS）
- **AWS**: EC2 + RDS + S3（Dockerなし、Nginx + Gunicorn）
- **避ける**: React/Vue、過度なSPA化、複雑すぎるインフラ

---

## 🔗 関連情報

### GitLabリポジトリ
- メインリポジトリ: labapp（最新コミット: f10d38b）

### MCP設定
- 設定ファイル: `/home/hirok/work/labapp/.claude_project_config.json`
- 接続中: filesystem, postgresql, git, memory

### 過去課題分析
1. [残業管理システム](/home/hirok/work/labapp/docs/past-challenges/CHALLENGE_01_OVERTIME_MANAGEMENT.md)
2. [母子健康手帳](/home/hirok/work/labapp/docs/past-challenges/CHALLENGE_02_MATERNAL_HEALTH_HANDBOOK.md)
3. [野球部記録管理](/home/hirok/work/labapp/docs/past-challenges/CHALLENGE_03_BASEBALL_TALENT_MANAGEMENT.md)
4. [図書館システム](/home/hirok/work/labapp/docs/past-challenges/CHALLENGE_04_LIBRARY_SYSTEM.md)

---

## ✅ チェックリスト（新規セッション開始時）

### AIアシスタント確認項目
- [ ] このREADMEを読んだ
- [ ] [インターンシップ準備_完全ガイド.md](/home/hirok/work/school_diary/docs-private/インターンシップ準備_完全ガイド.md)を確認した
- [ ] 現在の優先事項を理解した
- [ ] プロジェクト構造を把握した
- [ ] 設計方針と制約を理解した

### ユーザーへの最初の質問
1. 「今日はどの作業をサポートしますか？」
2. 「Tier 1の実装（notifications, reports, io）でしょうか？」
3. 「実装ガイドは確認されましたか？」

---

**最終更新**: 2025-10-05
**用途**: AIアシスタント向けクイックリファレンス
**バージョン**: 2.1.0

#ai #assistant #reference #labapp #kits #internship