# 情報管理ガイド（AI向け）

**作成日:** 2025-10-05
**目的:** 新しいスレッド開始時に、正確に引き継ぎを行うための情報管理ルール

---

## 🎯 基本方針：ハイブリッド戦略

**静的情報 = Markdownファイル**（プロジェクトの「憲法」）
**動的情報 = MCP Memory**（プロジェクトの「日誌」）

---

## 📁 情報の保存場所マップ

### Markdownファイル（静的・構造的情報）

| ファイル | 内容 | 更新頻度 |
|---------|------|---------|
| `/docs/README_AI向け.md` | プロジェクト全体像、技術スタック、ディレクトリ構造 | 月1回 |
| `/docs/ARCHITECTURE.md` | アーキテクチャ設計判断の記録 | 重要判断時 |
| `/docs/kits/DOCUMENTATION_PROCESS.md` | ドキュメント化プロセス標準 | ほぼ不変 |
| `/docs/kits_*実装ガイド.md` | 各kits実装手順 | 完成時のみ |
| `/docs/kits/*/00_実装ログ.md` | 実装の時系列記録 | 実装中毎日 |
| `/docs/kits/*/01-06_*.md` | 各kitsのドキュメント | 完成時 |

### MCP Memory（動的・進捗情報）

| エンティティ | 内容 | 更新頻度 |
|------------|------|---------|
| `labapp_project` | プロジェクト基本情報（変更少ない） | 週1回 |
| `kits_implementation_status` | 各kitsの実装進捗率 | 毎セッション |
| `次のタスク` | 次にやるべきこと | 毎セッション |
| `技術的課題` | 未解決の問題 | 問題発生時 |
| `{機能名}_実装記録` | 個別機能の実装詳細 | 実装中 |

---

## 🔄 新スレッド開始時の標準手順

### 【必須】毎回実行する3ステップ

#### Step 1: MCP Memory接続・読み込み
```python
# Memory全体を読み込み
mcp__memory__read_graph()

# または特定エンティティを検索
mcp__memory__search_nodes("labapp")
mcp__memory__search_nodes("kits")
mcp__memory__search_nodes("次のタスク")
```

#### Step 2: 静的ドキュメント確認
```bash
# 必須
Read /home/hirok/work/school_diary/docs-private/README_AI向け.md

# タスク依存（実装中の場合）
Read /home/hirok/work/school_diary/docs-private/kits_*実装ガイド.md
Read /home/hirok/work/school_diary/docs-private/kits/*/00_実装ログ.md
```

#### Step 3: 状況サマリー作成
```markdown
AIが自動生成すべき内容：

## 現在の状況
- プロジェクト: labapp
- 実装中: kits.reports Step3
- 進捗: Step1-2完了、Step3-10未実装
- 次のタスク: データモデル実装 + ドキュメント化

## 直近の作業履歴
- 2025-10-05: Step1-2完了（環境構築）
- 2025-10-05: ドキュメントプロセス標準化
- 2025-10-05: Ruffエラー解消

## 未解決の課題
- なし（全てクリーン）
```

---

## 📋 情報の保存ルール詳細

### 【Markdownに保存すべき情報】

#### ✅ 保存する
- プロジェクト概要（不変）
- 技術スタック（変更少ない）
- アーキテクチャ設計判断（重要）
- ディレクトリ構造（変更少ない）
- 開発方針・原則（不変）
- 実装ガイド（完成後）
- ドキュメント化プロセス（標準化後）

#### ❌ 保存しない
- 実装進捗率（→ Memory）
- 次のタスク（→ Memory）
- 技術的課題（解決前）（→ Memory）
- 一時的なメモ（→ Memory）

### 【MCP Memoryに保存すべき情報】

#### ✅ 保存する
- 実装進捗率（kits.reports 10%等）
- 次のタスク（Step3開始等）
- 技術的課題（未解決のみ）
- 最近の設計判断（一時的）
- エラーと解決策（実装中）
- 学んだこと（実装中）

#### ❌ 保存しない
- プロジェクト全体像（→ Markdown）
- 不変の技術スタック（→ Markdown）
- 完成したドキュメント内容（→ Markdown）

---

## 🔧 情報の移行ルール

### Memory → Markdownへの移行タイミング

```
【ケース1】実装完了時
Memory: "kits.reports Step10完了"
  ↓
Markdown: README_AI向け.mdの「完成済み」リストに追加
Memory: 該当observationを削除

【ケース2】設計判断が確定
Memory: "UUIDを採用、理由はセキュリティ"
  ↓
Markdown: ARCHITECTURE.mdに詳細記録
Memory: 該当observationを削除（またはMarkdown参照に変更）

【ケース3】課題解決
Memory: "Ruff ERA001誤検出、# noqa: ERA001で解決"
  ↓
Markdown: 該当kitsの06_よくある質問.mdに追加
Memory: 該当observationを削除
```

---

## 📊 情報フロー図

```
【新スレッド開始】
    ↓
┌─────────────────────┐
│ 1. Memory読み込み    │ → 動的情報取得
│ 2. Markdown読み込み  │ → 静的情報取得
└─────────────────────┘
    ↓
┌─────────────────────┐
│ コンテキスト統合     │
│ - 現在の進捗        │
│ - プロジェクト構造   │
│ - 次のタスク        │
└─────────────────────┘
    ↓
┌─────────────────────┐
│ 作業開始            │
└─────────────────────┘
    ↓
【実装中】
    ↓
Memory更新（進捗、課題）
    ↓
【完了時・判断確定時】
    ↓
Markdown更新（ARCHITECTURE.md等）
Memory整理（不要な情報削除）
```

---

## ✅ チェックリスト

### 新スレッド開始時（AI実行）
- [ ] `mcp__memory__read_graph()`実行
- [ ] `/docs/README_AI向け.md`読み込み
- [ ] 進捗状況の確認（from Memory）
- [ ] 次のタスクの確認（from Memory）
- [ ] 状況サマリーをユーザーに提示

### 実装中（AI実行）
- [ ] 進捗をMemoryに記録
- [ ] 技術的課題をMemoryに記録
- [ ] 設計判断をMemoryに記録（一時的）

### 完了時・判断確定時（AI実行）
- [ ] 重要な判断をMarkdownに移行
- [ ] 完成情報をMarkdownに移行
- [ ] Memoryの不要情報を削除

---

## 🎯 この仕組みの利点

### 1. 情報の永続性
- Markdown: Gitで管理、永続的
- Memory: セッションベース、動的

### 2. 検索性
- Markdown: 構造化、人間が読みやすい
- Memory: グラフ検索、関連性を辿れる

### 3. 更新効率
- Markdown: 手動編集しやすい
- Memory: AIが自律的に更新

### 4. 役割分担
- Markdown: 「なぜそうしたか」の記録
- Memory: 「今どうなっているか」の記録

---

## 📝 実例：kits.reports現在の状態

### Markdownに保存されている情報
```
/docs/README_AI向け.md:
- プロジェクト概要
- 技術スタック
- kits一覧

/docs/kits/DOCUMENTATION_PROCESS.md:
- ドキュメント化プロセス
- 7ファイル構成
- 品質チェックリスト

/docs/kits/reports/00_実装ログ.md:
- Step1-2の詳細記録
- 判断理由
- 学んだこと
```

### Memoryに保存されている情報
```
kits_implementation_status:
- "2025-10-05: kits.reports Step1-2完了"
- "進捗: Step3開始予定"

次のタスク:
- "Step3データモデル実装"
- "01-03ドキュメント作成"
```

---

## 🔄 今後の改善

### Phase 1（完了）
- ✅ ハイブリッド戦略の確立
- ✅ 情報管理ガイド作成

### Phase 2（今後）
- [ ] ARCHITECTURE.mdの作成開始
- [ ] Memory情報の定期クリーンアップ
- [ ] 情報移行の自動化検討

---

**更新日時:** 2025-10-05 12:15
**作成者:** Claude Code
**適用開始:** 2025-10-05
