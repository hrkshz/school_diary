# 連絡帳管理システム - データモデル設計書

## 作成日
2025-10-06

## データベース設計概要

### テーブル一覧
1. **User** - ユーザー（Django標準のauth_user）
2. **DiaryEntry** - 連絡帳エントリー
3. **ClassRoom** - クラス
4. **ClassRoomStudent** - クラス-生徒中間テーブル（ManyToMany関係）
5. **TeacherNote** - 担任メモ（課題2用）

---

## 1. Userテーブル
**説明**: Django標準のauth.Userモデルを使用

### フィールド
| フィールド名 | 型 | 制約 | 説明 |
|------------|---|-----|-----|
| id | BigInt | PK, Auto | 主キー |
| username | Varchar(150) | Unique, Not Null | ユーザー名 |
| email | Varchar(254) | - | メールアドレス |
| first_name | Varchar(150) | - | 名 |
| last_name | Varchar(150) | - | 姓 |
| is_staff | Boolean | Default: false | 管理者フラグ |
| is_active | Boolean | Default: true | アクティブフラグ |
| date_joined | Timestamp | Default: now() | 登録日時 |

### ロール
- **管理者**: is_staff = true
- **担任**: homeroom_classesに登録されている
- **生徒**: classesに登録されている

---

## 2. DiaryEntryテーブル
**説明**: 連絡帳の個別エントリー

### フィールド
| フィールド名 | 型 | 制約 | 説明 |
|------------|---|-----|-----|
| id | BigInt | PK, Auto | 主キー |
| student_id | BigInt | FK(User), Not Null | 生徒（外部キー） |
| entry_date | Date | Not Null | 記載日（前日の日付） |
| submission_date | Timestamp | Default: now() | 提出日時 |
| health_condition | Int | Not Null | 体調（1-5の5段階） |
| mental_condition | Int | Not Null | メンタル（1-5の5段階） |
| reflection | Text | Not Null | 今日の振り返り |
| is_read | Boolean | Default: false | 既読フラグ |
| read_by_id | BigInt | FK(User), Null | 既読者（担任） |
| read_at | Timestamp | Null | 既読日時 |

### インデックス
- `(student_id, entry_date)` - UNIQUE（1生徒につき1日1エントリー）
- `entry_date` - 日付検索用
- `is_read` - 未読検索用

### Choices
**health_condition / mental_condition**:
- 1: とても悪い / とても落ち込んでいる
- 2: 悪い / 落ち込んでいる
- 3: 普通
- 4: 良い / 元気
- 5: とても良い / とても元気

---

## 3. ClassRoomテーブル
**説明**: クラス情報

### フィールド
| フィールド名 | 型 | 制約 | 説明 |
|------------|---|-----|-----|
| id | BigInt | PK, Auto | 主キー |
| grade | Int | Not Null | 学年（1-3） |
| class_name | Varchar(10) | Not Null | クラス名（A, B, C） |
| academic_year | Int | Default: 2025 | 年度 |
| homeroom_teacher_id | BigInt | FK(User), Null | 担任（外部キー） |
| students | ManyToMany | - | 生徒（多対多関係） |

### インデックス
- `(grade, class_name, academic_year)` - UNIQUE（年度内で一意）

### プロパティ
- `student_count`: 生徒数を返す

---

## 4. ClassRoomStudentテーブル
**説明**: クラスと生徒の多対多関係を管理する中間テーブル
（Djangoでは自動生成されるが、ER図では明示）

### フィールド
| フィールド名 | 型 | 制約 | 説明 |
|------------|---|-----|-----|
| classroom_id | BigInt | FK(ClassRoom), PK | クラスID |
| student_id | BigInt | FK(User), PK | 生徒ID |

### インデックス
- `(classroom_id, student_id)` - PRIMARY KEY

---

## 5. TeacherNoteテーブル
**説明**: 担任が連絡帳に付けるメモ（課題2: 担任間共有機能用）

### フィールド
| フィールド名 | 型 | 制約 | 説明 |
|------------|---|-----|-----|
| id | BigInt | PK, Auto | 主キー |
| diary_entry_id | BigInt | FK(DiaryEntry), Not Null | 連絡帳エントリー |
| teacher_id | BigInt | FK(User), Not Null | 担任 |
| note | Text | Not Null | メモ内容 |
| is_shared | Boolean | Default: false | 学年会議で共有するか |
| created_at | Timestamp | Default: now() | 作成日時 |

---

## リレーション図

```
User (生徒)
  |
  +-- 1:N --> DiaryEntry
  |              |
  |              +-- 1:N --> TeacherNote
  |
  +-- N:M --> ClassRoom
                  |
                  +-- N:1 --> User (担任)

User (担任)
  |
  +-- 1:N --> ClassRoom (homeroom_teacher)
  |
  +-- 1:N --> DiaryEntry (read_by)
  |
  +-- 1:N --> TeacherNote (teacher)
```

---

## データ整合性ルール

### 1. unique_together
- `DiaryEntry`: `(student, entry_date)` - 1日1エントリーのみ
- `ClassRoom`: `(grade, class_name, academic_year)` - 年度内で一意のクラス

### 2. CASCADE削除
- ClassRoomが削除されると、関連するTeacherNoteもCASCADE削除
- DiaryEntryが削除されると、関連するTeacherNoteもCASCADE削除

### 3. SET_NULL
- User（担任）が削除されても、ClassRoomのhomeroom_teacherはSET_NULL
- User（担任）が削除されても、DiaryEntryのread_byはSET_NULL

---

## 今後の拡張（Phase 2以降）

### MLP Phase（カスタムUI実装時）
- DiaryEntryに`edited_at`フィールド追加（編集履歴）
- `image`フィールド追加（写真添付機能）

### MAP Phase（グラフ機能実装時）
- 統計用のViewやMaterialized Viewの検討
- 集計クエリの最適化

### AWS Phase（本番環境構築時）
- インデックスの最適化
- クエリパフォーマンスのチューニング

---

## 参考資料
- ER図: `school_diary_er.sql`
- dbdiagram.io形式: `school_diary_er.dbml`
- Django公式ドキュメント: https://docs.djangoproject.com/
