-- 連絡帳管理システム - ER図SQLエクスポート

-- ユーザーテーブル（Django標準のauth_user）
CREATE TABLE "User" (
  "id" BIGSERIAL PRIMARY KEY,
  "username" VARCHAR(150) UNIQUE NOT NULL,
  "email" VARCHAR(254),
  "first_name" VARCHAR(150),
  "last_name" VARCHAR(150),
  "is_staff" BOOLEAN DEFAULT false,
  "is_active" BOOLEAN DEFAULT true,
  "date_joined" TIMESTAMP DEFAULT now()
);

-- 連絡帳エントリーテーブル
CREATE TABLE "DiaryEntry" (
  "id" BIGSERIAL PRIMARY KEY,
  "student_id" BIGINT NOT NULL,
  "entry_date" DATE NOT NULL,
  "submission_date" TIMESTAMP DEFAULT now(),
  "health_condition" INT NOT NULL,
  "mental_condition" INT NOT NULL,
  "reflection" TEXT NOT NULL,
  "is_read" BOOLEAN DEFAULT false,
  "read_by_id" BIGINT,
  "read_at" TIMESTAMP
);

-- クラステーブル
CREATE TABLE "ClassRoom" (
  "id" BIGSERIAL PRIMARY KEY,
  "grade" INT NOT NULL,
  "class_name" VARCHAR(10) NOT NULL,
  "academic_year" INT DEFAULT 2025,
  "homeroom_teacher_id" BIGINT
);

-- クラス-生徒中間テーブル（ManyToMany）
CREATE TABLE "ClassRoomStudent" (
  "classroom_id" BIGINT,
  "student_id" BIGINT,
  PRIMARY KEY ("classroom_id", "student_id")
);

-- 担任メモテーブル
CREATE TABLE "TeacherNote" (
  "id" BIGSERIAL PRIMARY KEY,
  "diary_entry_id" BIGINT NOT NULL,
  "teacher_id" BIGINT NOT NULL,
  "note" TEXT NOT NULL,
  "is_shared" BOOLEAN DEFAULT false,
  "created_at" TIMESTAMP DEFAULT now()
);

-- 外部キー制約
ALTER TABLE "DiaryEntry" ADD FOREIGN KEY ("student_id") REFERENCES "User" ("id");
ALTER TABLE "DiaryEntry" ADD FOREIGN KEY ("read_by_id") REFERENCES "User" ("id");
ALTER TABLE "ClassRoom" ADD FOREIGN KEY ("homeroom_teacher_id") REFERENCES "User" ("id");
ALTER TABLE "ClassRoomStudent" ADD FOREIGN KEY ("classroom_id") REFERENCES "ClassRoom" ("id");
ALTER TABLE "ClassRoomStudent" ADD FOREIGN KEY ("student_id") REFERENCES "User" ("id");
ALTER TABLE "TeacherNote" ADD FOREIGN KEY ("diary_entry_id") REFERENCES "DiaryEntry" ("id");
ALTER TABLE "TeacherNote" ADD FOREIGN KEY ("teacher_id") REFERENCES "User" ("id");

-- インデックス
CREATE UNIQUE INDEX ON "DiaryEntry" ("student_id", "entry_date");
CREATE INDEX ON "DiaryEntry" ("entry_date");
CREATE INDEX ON "DiaryEntry" ("is_read");
CREATE UNIQUE INDEX ON "ClassRoom" ("grade", "class_name", "academic_year");

-- コメント
COMMENT ON COLUMN "DiaryEntry"."student_id" IS '生徒';
COMMENT ON COLUMN "DiaryEntry"."entry_date" IS '記載日（前日）';
COMMENT ON COLUMN "DiaryEntry"."submission_date" IS '提出日時';
COMMENT ON COLUMN "DiaryEntry"."health_condition" IS '1-5の5段階評価';
COMMENT ON COLUMN "DiaryEntry"."mental_condition" IS '1-5の5段階評価';
COMMENT ON COLUMN "DiaryEntry"."reflection" IS '今日の振り返り';
COMMENT ON COLUMN "DiaryEntry"."read_by_id" IS '既読者（担任）';
COMMENT ON COLUMN "ClassRoom"."grade" IS '1-3';
COMMENT ON COLUMN "ClassRoom"."class_name" IS 'A, B, C';
COMMENT ON COLUMN "TeacherNote"."is_shared" IS '学年会議で共有';
