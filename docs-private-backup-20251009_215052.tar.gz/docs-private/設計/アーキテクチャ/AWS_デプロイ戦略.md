# AWS デプロイ戦略 - school_diary プロジェクト

> **対象**: インフラ経験者向け AWS デプロイガイド
> **前提**: Docker Compose で開発完了、AWS 基礎知識あり
> **目的**: ローカルの Docker 環境を AWS に移行する全手順を理解する
> **作成日**: 2025-10-09
> **バージョン**: 1.0.0

---

## 📖 目次

1. [全体像: Docker → AWS マッピング](#1-全体像-docker--aws-マッピング)
2. [アーキテクチャ選択肢（3 パターン）](#2-アーキテクチャ選択肢3パターン)
3. [推奨構成: ECS + RDS パターン](#3-推奨構成-ecs--rds-パターン)
4. [デプロイ手順（ステップバイステップ）](#4-デプロイ手順ステップバイステップ)
5. [CI/CD パイプライン構築](#5-cicd-パイプライン構築)
6. [本番運用設定](#6-本番運用設定)
7. [コスト試算](#7-コスト試算)
8. [トラブルシューティング](#8-トラブルシューティング)

---

## 1. 全体像: Docker → AWS マッピング

### 1.1 ローカル環境の構成（Docker Compose）

```yaml
# docker-compose.local.yml
services:
  django: # Webアプリケーション
  postgres: # データベース
  redis: # キャッシュ・メッセージブローカー
  celeryworker: # 非同期タスク実行
  celerybeat: # 定期実行スケジューラー
  flower: # Celery監視ツール
  mailpit: # 開発用メールサーバー（本番不要）
```

**7 つのコンテナ**が連携して動いています。

---

### 1.2 AWS へのマッピング

| ローカル (Docker) | AWS サービス               | 説明                                 |
| ----------------- | -------------------------- | ------------------------------------ |
| **django**        | ECS/Fargate + ALB          | アプリケーションサーバー（コンテナ） |
| **postgres**      | RDS (PostgreSQL)           | マネージドデータベース               |
| **redis**         | ElastiCache (Redis)        | マネージドキャッシュ                 |
| **celeryworker**  | ECS/Fargate                | 非同期タスク実行（別タスク）         |
| **celerybeat**    | ECS/Fargate                | 定期実行スケジューラー（別タスク）   |
| **flower**        | ECS/Fargate (Optional)     | 監視ツール（開発/ステージング用）    |
| **mailpit**       | SES                        | 本番用メールサービス                 |
| **静的ファイル**  | S3 + CloudFront            | CDN 配信                             |
| **ネットワーク**  | VPC, Subnet, SecurityGroup | ネットワーク分離                     |
| **ログ**          | CloudWatch Logs            | ログ集約                             |
| **監視**          | CloudWatch + SNS           | アラート通知                         |
| **デプロイ**      | CodePipeline + CodeBuild   | CI/CD                                |
| **ドメイン・SSL** | Route53 + ACM              | DNS + SSL 証明書                     |

---

### 1.3 アーキテクチャ図（AWS）

```
                              ┌─────────────────┐
                              │   Route 53      │
                              │  (DNS管理)       │
                              └────────┬────────┘
                                       │
                              ┌────────▼────────┐
                              │  CloudFront     │
                              │  (CDN, SSL)     │
                              └────┬───────┬────┘
                                   │       │
                 ┌─────────────────┘       └─────────────────┐
                 │                                           │
        ┌────────▼────────┐                         ┌───────▼───────┐
        │  S3 Bucket      │                         │  ALB          │
        │  (静的ファイル)  │                         │  (Load Balancer)│
        └─────────────────┘                         └───────┬───────┘
                                                            │
                                       ┌────────────────────┼────────────────────┐
                                       │                    │                    │
                              ┌────────▼────────┐  ┌────────▼────────┐  ┌───────▼────────┐
                              │ ECS Fargate     │  │ ECS Fargate     │  │ ECS Fargate    │
                              │ (Django Task)   │  │ (Celery Worker) │  │ (Celery Beat)  │
                              └────────┬────────┘  └────────┬────────┘  └───────┬────────┘
                                       │                    │                    │
                                       └────────────────────┼────────────────────┘
                                                            │
                                       ┌────────────────────┼────────────────────┐
                                       │                    │                    │
                              ┌────────▼────────┐  ┌────────▼────────┐  ┌───────▼────────┐
                              │  RDS            │  │ ElastiCache     │  │ SES            │
                              │  (PostgreSQL)   │  │ (Redis)         │  │ (メール送信)    │
                              └─────────────────┘  └─────────────────┘  └────────────────┘

全て VPC 内（プライベートサブネット）
```

---

## 2. アーキテクチャ選択肢（3 パターン）

### パターン A: ECS Fargate + RDS（推奨）⭐

**構成**:

- アプリ: ECS Fargate（サーバーレスコンテナ）
- DB: RDS PostgreSQL
- キャッシュ: ElastiCache Redis
- 静的ファイル: S3 + CloudFront

**メリット**:

- ✅ サーバー管理不要（フルマネージド）
- ✅ スケールが容易（ECS Auto Scaling）
- ✅ Docker イメージをそのまま使える
- ✅ コスト最適化（使った分だけ）

**デメリット**:

- ❌ EC2 より若干コスト高（小規模の場合）
- ❌ Cold Start あり（初回起動が遅い）

**推奨ケース**:

- 本番環境
- トラフィック変動が大きい
- 運用コストを抑えたい

**月額コスト**: 約 $50-80（開発環境）、$150-250（本番環境）

---

### パターン B: EC2 + Docker Compose

**構成**:

- アプリ: EC2（t3.medium）上で Docker Compose
- DB: RDS PostgreSQL
- キャッシュ: ElastiCache Redis

**メリット**:

- ✅ ローカル環境と同じ構成
- ✅ シンプル（学習コスト低）
- ✅ デバッグしやすい

**デメリット**:

- ❌ サーバー管理が必要（OS 更新等）
- ❌ スケールしにくい
- ❌ 単一障害点（EC2 が落ちると全停止）

**推奨ケース**:

- 開発/ステージング環境
- 小規模プロジェクト
- 学習目的

**月額コスト**: 約 $30-50（t3.medium）

---

### パターン C: App Runner + RDS（最もシンプル）

**構成**:

- アプリ: App Runner（フルマネージドコンテナ）
- DB: RDS PostgreSQL
- キャッシュ: ElastiCache Redis（Optional）

**メリット**:

- ✅ 最もシンプル（設定が少ない）
- ✅ CI/CD 自動構築
- ✅ Auto Scaling 標準装備

**デメリット**:

- ❌ カスタマイズ性が低い
- ❌ VPC 統合が複雑
- ❌ Celery の複数タスクを動かしにくい

**推奨ケース**:

- PoC / MVP
- Celery を使わないシンプルなアプリ

**月額コスト**: 約 $25-40

---

### 選択基準

| 項目                 | ECS Fargate | EC2 + Docker | App Runner |
| -------------------- | ----------- | ------------ | ---------- |
| **管理の容易さ**     | ⭐⭐⭐⭐    | ⭐⭐         | ⭐⭐⭐⭐⭐ |
| **スケーラビリティ** | ⭐⭐⭐⭐⭐  | ⭐⭐         | ⭐⭐⭐⭐   |
| **カスタマイズ性**   | ⭐⭐⭐⭐    | ⭐⭐⭐⭐⭐   | ⭐⭐       |
| **コスト効率**       | ⭐⭐⭐      | ⭐⭐⭐⭐     | ⭐⭐⭐     |
| **学習コスト**       | ⭐⭐⭐      | ⭐⭐⭐⭐     | ⭐⭐⭐⭐⭐ |
| **本番運用適性**     | ⭐⭐⭐⭐⭐  | ⭐⭐⭐       | ⭐⭐⭐⭐   |

**結論**: **ECS Fargate + RDS** を推奨（バランスが最良）

---

## 3. 推奨構成: ECS + RDS パターン

### 3.1 詳細構成図

```
┌─────────────────────────────────────────────────────────────────┐
│                       AWS Account                                │
│                                                                   │
│  ┌─────────────────────────────────────────────────────────┐   │
│  │                      VPC (10.0.0.0/16)                   │   │
│  │                                                           │   │
│  │  ┌──────────────────┐           ┌──────────────────┐   │   │
│  │  │ Public Subnet A  │           │ Public Subnet B  │   │   │
│  │  │  (10.0.1.0/24)   │           │  (10.0.2.0/24)   │   │   │
│  │  │                  │           │                  │   │   │
│  │  │  ┌─────────────┐ │           │ ┌─────────────┐ │   │   │
│  │  │  │     ALB     │ │           │ │   (Backup)  │ │   │   │
│  │  │  └─────────────┘ │           │ └─────────────┘ │   │   │
│  │  └──────────────────┘           └──────────────────┘   │   │
│  │           │                               │             │   │
│  │           │                               │             │   │
│  │  ┌────────▼───────────┐       ┌──────────▼─────────┐  │   │
│  │  │ Private Subnet A   │       │ Private Subnet B   │  │   │
│  │  │  (10.0.11.0/24)    │       │  (10.0.12.0/24)    │  │   │
│  │  │                    │       │                    │  │   │
│  │  │  ┌──────────────┐  │       │  ┌──────────────┐  │  │   │
│  │  │  │ ECS Task     │  │       │  │ ECS Task     │  │  │   │
│  │  │  │ (Django)     │  │       │  │ (Django)     │  │  │   │
│  │  │  └──────────────┘  │       │  └──────────────┘  │  │   │
│  │  │                    │       │                    │  │   │
│  │  │  ┌──────────────┐  │       │  ┌──────────────┐  │  │   │
│  │  │  │ ECS Task     │  │       │  │ ECS Task     │  │  │   │
│  │  │  │ (Celery)     │  │       │  │ (Celery)     │  │  │   │
│  │  │  └──────────────┘  │       │  └──────────────┘  │  │   │
│  │  └────────┬───────────┘       └──────────┬─────────┘  │   │
│  │           │                               │             │   │
│  │  ┌────────▼───────────┐       ┌──────────▼─────────┐  │   │
│  │  │ Data Subnet A      │       │ Data Subnet B      │  │   │
│  │  │  (10.0.21.0/24)    │       │  (10.0.22.0/24)    │  │   │
│  │  │                    │       │                    │  │   │
│  │  │  ┌──────────────┐  │       │  ┌──────────────┐  │  │   │
│  │  │  │ RDS Primary  │◄─┼───────┼─►│ RDS Standby  │  │  │   │
│  │  │  │ (PostgreSQL) │  │       │  │ (Replica)    │  │  │   │
│  │  │  └──────────────┘  │       │  └──────────────┘  │  │   │
│  │  │                    │       │                    │  │   │
│  │  │  ┌──────────────┐  │       │  ┌──────────────┐  │  │   │
│  │  │  │ ElastiCache  │  │       │  │ ElastiCache  │  │  │   │
│  │  │  │ (Redis)      │  │       │  │ (Replica)    │  │  │   │
│  │  │  └──────────────┘  │       │  └──────────────┘  │  │   │
│  │  └────────────────────┘       └────────────────────┘  │   │
│  │                                                         │   │
│  └─────────────────────────────────────────────────────────┘   │
│                                                                   │
│  ┌─────────────────────────────────────────────────────────┐   │
│  │                     S3 Bucket                            │   │
│  │  - 静的ファイル (CSS, JS, Images)                        │   │
│  │  - メディアファイル（ユーザーアップロード）                │   │
│  └─────────────────────────────────────────────────────────┘   │
│                                                                   │
│  ┌─────────────────────────────────────────────────────────┐   │
│  │                   CloudWatch Logs                        │   │
│  │  - Django アプリケーションログ                            │   │
│  │  - Celery ワーカーログ                                   │   │
│  │  - ALB アクセスログ                                      │   │
│  └─────────────────────────────────────────────────────────┘   │
│                                                                   │
│  ┌─────────────────────────────────────────────────────────┐   │
│  │                      ECR (Docker Registry)               │   │
│  │  - school-diary:latest                                   │   │
│  │  - school-diary:v1.0.0                                   │   │
│  └─────────────────────────────────────────────────────────┘   │
│                                                                   │
└───────────────────────────────────────────────────────────────────┘

外部サービス:
  - Route53 (DNS)
  - ACM (SSL証明書)
  - CloudFront (CDN)
  - SES (メール送信)
```

---

### 3.2 各コンポーネントの設定

#### 3.2.1 VPC 設定

```hcl
# Terraform例
resource "aws_vpc" "main" {
  cidr_block           = "10.0.0.0/16"
  enable_dns_hostnames = true
  enable_dns_support   = true

  tags = {
    Name = "school-diary-vpc"
  }
}

# パブリックサブネット（ALB用）
resource "aws_subnet" "public_a" {
  vpc_id                  = aws_vpc.main.id
  cidr_block              = "10.0.1.0/24"
  availability_zone       = "ap-northeast-1a"
  map_public_ip_on_launch = true

  tags = {
    Name = "school-diary-public-a"
  }
}

resource "aws_subnet" "public_b" {
  vpc_id                  = aws_vpc.main.id
  cidr_block              = "10.0.2.0/24"
  availability_zone       = "ap-northeast-1c"
  map_public_ip_on_launch = true

  tags = {
    Name = "school-diary-public-b"
  }
}

# プライベートサブネット（ECS Task用）
resource "aws_subnet" "private_a" {
  vpc_id            = aws_vpc.main.id
  cidr_block        = "10.0.11.0/24"
  availability_zone = "ap-northeast-1a"

  tags = {
    Name = "school-diary-private-a"
  }
}

resource "aws_subnet" "private_b" {
  vpc_id            = aws_vpc.main.id
  cidr_block        = "10.0.12.0/24"
  availability_zone = "ap-northeast-1c"

  tags = {
    Name = "school-diary-private-b"
  }
}

# データサブネット（RDS, ElastiCache用）
resource "aws_subnet" "data_a" {
  vpc_id            = aws_vpc.main.id
  cidr_block        = "10.0.21.0/24"
  availability_zone = "ap-northeast-1a"

  tags = {
    Name = "school-diary-data-a"
  }
}

resource "aws_subnet" "data_b" {
  vpc_id            = aws_vpc.main.id
  cidr_block        = "10.0.22.0/24"
  availability_zone = "ap-northeast-1c"

  tags = {
    Name = "school-diary-data-b"
  }
}
```

#### 3.2.2 セキュリティグループ

```hcl
# ALB用
resource "aws_security_group" "alb" {
  name        = "school-diary-alb-sg"
  vpc_id      = aws_vpc.main.id

  ingress {
    from_port   = 443
    to_port     = 443
    protocol    = "tcp"
    cidr_blocks = ["0.0.0.0/0"]
  }

  ingress {
    from_port   = 80
    to_port     = 80
    protocol    = "tcp"
    cidr_blocks = ["0.0.0.0/0"]
  }

  egress {
    from_port   = 0
    to_port     = 0
    protocol    = "-1"
    cidr_blocks = ["0.0.0.0/0"]
  }
}

# ECS Task用
resource "aws_security_group" "ecs_task" {
  name        = "school-diary-ecs-task-sg"
  vpc_id      = aws_vpc.main.id

  ingress {
    from_port       = 8000
    to_port         = 8000
    protocol        = "tcp"
    security_groups = [aws_security_group.alb.id]
  }

  egress {
    from_port   = 0
    to_port     = 0
    protocol    = "-1"
    cidr_blocks = ["0.0.0.0/0"]
  }
}

# RDS用
resource "aws_security_group" "rds" {
  name        = "school-diary-rds-sg"
  vpc_id      = aws_vpc.main.id

  ingress {
    from_port       = 5432
    to_port         = 5432
    protocol        = "tcp"
    security_groups = [aws_security_group.ecs_task.id]
  }
}

# ElastiCache用
resource "aws_security_group" "elasticache" {
  name        = "school-diary-elasticache-sg"
  vpc_id      = aws_vpc.main.id

  ingress {
    from_port       = 6379
    to_port         = 6379
    protocol        = "tcp"
    security_groups = [aws_security_group.ecs_task.id]
  }
}
```

---

## 4. デプロイ手順（ステップバイステップ）

### Phase 0: 事前準備（30 分）

#### 0.1 AWS CLI 設定

```bash
# AWS CLI インストール確認
aws --version

# 認証情報設定
aws configure
# AWS Access Key ID: xxxxxxxx
# AWS Secret Access Key: xxxxxxxx
# Default region name: ap-northeast-1
# Default output format: json

# 確認
aws sts get-caller-identity
```

#### 0.2 必要なツールインストール

```bash
# Terraform（Infrastructure as Code）
wget https://releases.hashicorp.com/terraform/1.6.0/terraform_1.6.0_linux_amd64.zip
unzip terraform_1.6.0_linux_amd64.zip
sudo mv terraform /usr/local/bin/

# 確認
terraform version

# Docker（既にインストール済み）
docker --version
```

---

### Phase 1: Docker イメージ準備（60 分）

#### 1.1 本番用 Dockerfile 作成

```dockerfile
# Dockerfile.production
FROM python:3.12-slim

# 環境変数
ENV PYTHONUNBUFFERED=1 \
    PYTHONDONTWRITEBYTECODE=1 \
    PIP_NO_CACHE_DIR=1

# 作業ディレクトリ
WORKDIR /app

# システム依存関係
RUN apt-get update && apt-get install -y \
    postgresql-client \
    build-essential \
    libpq-dev \
    && rm -rf /var/lib/apt/lists/*

# Python依存関係
COPY pyproject.toml uv.lock ./
RUN pip install uv && \
    uv pip install --system -r pyproject.toml

# アプリケーションコード
COPY . .

# 静的ファイル収集
RUN python manage.py collectstatic --noinput

# ヘルスチェック
HEALTHCHECK --interval=30s --timeout=3s --start-period=40s \
  CMD python -c "import requests; requests.get('http://localhost:8000/health')"

# 起動コマンド
CMD ["gunicorn", "config.wsgi:application", "--bind", "0.0.0.0:8000", "--workers", "4"]
```

#### 1.2 ECR リポジトリ作成

```bash
# ECRリポジトリ作成
aws ecr create-repository \
  --repository-name school-diary \
  --region ap-northeast-1

# 出力例:
# {
#   "repository": {
#     "repositoryUri": "123456789012.dkr.ecr.ap-northeast-1.amazonaws.com/school-diary"
#   }
# }

# ECRログイン
aws ecr get-login-password --region ap-northeast-1 | \
  docker login --username AWS --password-stdin 123456789012.dkr.ecr.ap-northeast-1.amazonaws.com
```

#### 1.3 イメージビルド・プッシュ

```bash
# イメージビルド
docker build -f Dockerfile.production -t school-diary:latest .

# タグ付け
docker tag school-diary:latest \
  123456789012.dkr.ecr.ap-northeast-1.amazonaws.com/school-diary:latest

docker tag school-diary:latest \
  123456789012.dkr.ecr.ap-northeast-1.amazonaws.com/school-diary:v1.0.0

# プッシュ
docker push 123456789012.dkr.ecr.ap-northeast-1.amazonaws.com/school-diary:latest
docker push 123456789012.dkr.ecr.ap-northeast-1.amazonaws.com/school-diary:v1.0.0
```

---

### Phase 2: データベース構築（45 分）

#### 2.1 RDS（PostgreSQL）作成

```bash
# サブネットグループ作成
aws rds create-db-subnet-group \
  --db-subnet-group-name school-diary-db-subnet \
  --db-subnet-group-description "School Diary DB Subnet Group" \
  --subnet-ids subnet-xxxxxx subnet-yyyyyy \
  --region ap-northeast-1

# RDSインスタンス作成
aws rds create-db-instance \
  --db-instance-identifier school-diary-db \
  --db-instance-class db.t3.micro \
  --engine postgres \
  --engine-version 16.1 \
  --master-username dbadmin \
  --master-user-password "YourStrongPassword123!" \
  --allocated-storage 20 \
  --storage-type gp3 \
  --db-subnet-group-name school-diary-db-subnet \
  --vpc-security-group-ids sg-xxxxxx \
  --backup-retention-period 7 \
  --preferred-backup-window "03:00-04:00" \
  --preferred-maintenance-window "mon:04:00-mon:05:00" \
  --multi-az \
  --publicly-accessible false \
  --region ap-northeast-1

# 作成完了まで待機（5-10分）
aws rds wait db-instance-available \
  --db-instance-identifier school-diary-db

# エンドポイント取得
aws rds describe-db-instances \
  --db-instance-identifier school-diary-db \
  --query 'DBInstances[0].Endpoint.Address' \
  --output text

# 出力例: school-diary-db.xxxxxx.ap-northeast-1.rds.amazonaws.com
```

#### 2.2 データベース初期化

```bash
# 踏み台サーバー（Bastion）から接続
# または、ECS Exec を使う

# マイグレーション実行（後述のECSタスクで実行）
docker run --rm \
  -e DATABASE_URL="postgresql://dbadmin:YourStrongPassword123!@school-diary-db.xxxxxx.ap-northeast-1.rds.amazonaws.com:5432/postgres" \
  123456789012.dkr.ecr.ap-northeast-1.amazonaws.com/school-diary:latest \
  python manage.py migrate

# テストユーザー作成
docker run --rm \
  -e DATABASE_URL="..." \
  123456789012.dkr.ecr.ap-northeast-1.amazonaws.com/school-diary:latest \
  python manage.py setup_dev
```

---

### Phase 3: キャッシュ構築（30 分）

#### 3.1 ElastiCache（Redis）作成

```bash
# サブネットグループ作成
aws elasticache create-cache-subnet-group \
  --cache-subnet-group-name school-diary-redis-subnet \
  --cache-subnet-group-description "School Diary Redis Subnet Group" \
  --subnet-ids subnet-xxxxxx subnet-yyyyyy \
  --region ap-northeast-1

# Redisクラスター作成
aws elasticache create-cache-cluster \
  --cache-cluster-id school-diary-redis \
  --engine redis \
  --engine-version 7.0 \
  --cache-node-type cache.t3.micro \
  --num-cache-nodes 1 \
  --cache-subnet-group-name school-diary-redis-subnet \
  --security-group-ids sg-xxxxxx \
  --region ap-northeast-1

# 作成完了まで待機
aws elasticache wait cache-cluster-available \
  --cache-cluster-id school-diary-redis

# エンドポイント取得
aws elasticache describe-cache-clusters \
  --cache-cluster-id school-diary-redis \
  --show-cache-node-info \
  --query 'CacheClusters[0].CacheNodes[0].Endpoint.Address' \
  --output text

# 出力例: school-diary-redis.xxxxxx.0001.apne1.cache.amazonaws.com
```

---

### Phase 4: ECS 構築（90 分）

#### 4.1 ECS クラスター作成

```bash
# クラスター作成
aws ecs create-cluster \
  --cluster-name school-diary-cluster \
  --region ap-northeast-1
```

#### 4.2 タスク定義作成

```json
{
  "family": "school-diary-django",
  "networkMode": "awsvpc",
  "requiresCompatibilities": ["FARGATE"],
  "cpu": "512",
  "memory": "1024",
  "executionRoleArn": "arn:aws:iam::123456789012:role/ecsTaskExecutionRole",
  "taskRoleArn": "arn:aws:iam::123456789012:role/ecsTaskRole",
  "containerDefinitions": [
    {
      "name": "django",
      "image": "123456789012.dkr.ecr.ap-northeast-1.amazonaws.com/school-diary:latest",
      "cpu": 512,
      "memory": 1024,
      "essential": true,
      "portMappings": [
        {
          "containerPort": 8000,
          "protocol": "tcp"
        }
      ],
      "environment": [
        {
          "name": "DJANGO_SETTINGS_MODULE",
          "value": "config.settings.production"
        },
        {
          "name": "ALLOWED_HOSTS",
          "value": ".school-diary.com,alb-xxxxxx.ap-northeast-1.elb.amazonaws.com"
        }
      ],
      "secrets": [
        {
          "name": "DATABASE_URL",
          "valueFrom": "arn:aws:secretsmanager:ap-northeast-1:123456789012:secret:school-diary/database-url"
        },
        {
          "name": "SECRET_KEY",
          "valueFrom": "arn:aws:secretsmanager:ap-northeast-1:123456789012:secret:school-diary/secret-key"
        },
        {
          "name": "REDIS_URL",
          "valueFrom": "arn:aws:secretsmanager:ap-northeast-1:123456789012:secret:school-diary/redis-url"
        }
      ],
      "logConfiguration": {
        "logDriver": "awslogs",
        "options": {
          "awslogs-group": "/ecs/school-diary-django",
          "awslogs-region": "ap-northeast-1",
          "awslogs-stream-prefix": "ecs"
        }
      },
      "healthCheck": {
        "command": [
          "CMD-SHELL",
          "curl -f http://localhost:8000/health || exit 1"
        ],
        "interval": 30,
        "timeout": 5,
        "retries": 3,
        "startPeriod": 60
      }
    }
  ]
}
```

```bash
# タスク定義登録
aws ecs register-task-definition \
  --cli-input-json file://task-definition-django.json \
  --region ap-northeast-1
```

#### 4.3 Celery Worker タスク定義

```json
{
  "family": "school-diary-celery-worker",
  "networkMode": "awsvpc",
  "requiresCompatibilities": ["FARGATE"],
  "cpu": "256",
  "memory": "512",
  "executionRoleArn": "arn:aws:iam::123456789012:role/ecsTaskExecutionRole",
  "taskRoleArn": "arn:aws:iam::123456789012:role/ecsTaskRole",
  "containerDefinitions": [
    {
      "name": "celery-worker",
      "image": "123456789012.dkr.ecr.ap-northeast-1.amazonaws.com/school-diary:latest",
      "cpu": 256,
      "memory": 512,
      "essential": true,
      "command": ["celery", "-A", "config", "worker", "-l", "info"],
      "environment": [
        {
          "name": "DJANGO_SETTINGS_MODULE",
          "value": "config.settings.production"
        }
      ],
      "secrets": [
        {
          "name": "DATABASE_URL",
          "valueFrom": "arn:aws:secretsmanager:ap-northeast-1:123456789012:secret:school-diary/database-url"
        },
        {
          "name": "REDIS_URL",
          "valueFrom": "arn:aws:secretsmanager:ap-northeast-1:123456789012:secret:school-diary/redis-url"
        }
      ],
      "logConfiguration": {
        "logDriver": "awslogs",
        "options": {
          "awslogs-group": "/ecs/school-diary-celery-worker",
          "awslogs-region": "ap-northeast-1",
          "awslogs-stream-prefix": "ecs"
        }
      }
    }
  ]
}
```

```bash
# タスク定義登録
aws ecs register-task-definition \
  --cli-input-json file://task-definition-celery-worker.json \
  --region ap-northeast-1
```

#### 4.4 ALB 作成

```bash
# ALB作成
aws elbv2 create-load-balancer \
  --name school-diary-alb \
  --subnets subnet-xxxxxx subnet-yyyyyy \
  --security-groups sg-xxxxxx \
  --scheme internet-facing \
  --type application \
  --ip-address-type ipv4 \
  --region ap-northeast-1

# ターゲットグループ作成
aws elbv2 create-target-group \
  --name school-diary-tg \
  --protocol HTTP \
  --port 8000 \
  --vpc-id vpc-xxxxxx \
  --target-type ip \
  --health-check-enabled \
  --health-check-protocol HTTP \
  --health-check-path /health \
  --health-check-interval-seconds 30 \
  --health-check-timeout-seconds 5 \
  --healthy-threshold-count 2 \
  --unhealthy-threshold-count 3 \
  --region ap-northeast-1

# リスナー作成（HTTP → HTTPS リダイレクト）
aws elbv2 create-listener \
  --load-balancer-arn arn:aws:elasticloadbalancing:ap-northeast-1:123456789012:loadbalancer/app/school-diary-alb/xxxxxx \
  --protocol HTTP \
  --port 80 \
  --default-actions Type=redirect,RedirectConfig="{Protocol=HTTPS,Port=443,StatusCode=HTTP_301}" \
  --region ap-northeast-1

# リスナー作成（HTTPS）
aws elbv2 create-listener \
  --load-balancer-arn arn:aws:elasticloadbalancing:ap-northeast-1:123456789012:loadbalancer/app/school-diary-alb/xxxxxx \
  --protocol HTTPS \
  --port 443 \
  --certificates CertificateArn=arn:aws:acm:ap-northeast-1:123456789012:certificate/xxxxxx \
  --default-actions Type=forward,TargetGroupArn=arn:aws:elasticloadbalancing:ap-northeast-1:123456789012:targetgroup/school-diary-tg/xxxxxx \
  --region ap-northeast-1
```

#### 4.5 ECS サービス作成

```bash
# Djangoサービス
aws ecs create-service \
  --cluster school-diary-cluster \
  --service-name school-diary-django \
  --task-definition school-diary-django:1 \
  --desired-count 2 \
  --launch-type FARGATE \
  --platform-version LATEST \
  --network-configuration "awsvpcConfiguration={subnets=[subnet-xxxxxx,subnet-yyyyyy],securityGroups=[sg-xxxxxx],assignPublicIp=DISABLED}" \
  --load-balancers "targetGroupArn=arn:aws:elasticloadbalancing:ap-northeast-1:123456789012:targetgroup/school-diary-tg/xxxxxx,containerName=django,containerPort=8000" \
  --health-check-grace-period-seconds 60 \
  --region ap-northeast-1

# Celery Workerサービス
aws ecs create-service \
  --cluster school-diary-cluster \
  --service-name school-diary-celery-worker \
  --task-definition school-diary-celery-worker:1 \
  --desired-count 1 \
  --launch-type FARGATE \
  --platform-version LATEST \
  --network-configuration "awsvpcConfiguration={subnets=[subnet-xxxxxx,subnet-yyyyyy],securityGroups=[sg-xxxxxx],assignPublicIp=DISABLED}" \
  --region ap-northeast-1
```

---

### Phase 5: 静的ファイル・CDN（45 分）

#### 5.1 S3 バケット作成

```bash
# バケット作成
aws s3 mb s3://school-diary-static \
  --region ap-northeast-1

# バケットポリシー設定（CloudFront専用アクセス）
cat > bucket-policy.json <<EOF
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Sid": "AllowCloudFrontAccess",
      "Effect": "Allow",
      "Principal": {
        "AWS": "arn:aws:iam::cloudfront:user/CloudFront Origin Access Identity XXXXX"
      },
      "Action": "s3:GetObject",
      "Resource": "arn:aws:s3:::school-diary-static/*"
    }
  ]
}
EOF

aws s3api put-bucket-policy \
  --bucket school-diary-static \
  --policy file://bucket-policy.json
```

#### 5.2 静的ファイルアップロード

```bash
# Django設定更新（settings/production.py）
# AWS_STORAGE_BUCKET_NAME = 'school-diary-static'
# AWS_S3_CUSTOM_DOMAIN = '%s.s3.amazonaws.com' % AWS_STORAGE_BUCKET_NAME
# STATIC_URL = 'https://%s/' % AWS_S3_CUSTOM_DOMAIN

# collectstatic実行
python manage.py collectstatic --noinput

# S3にアップロード
aws s3 sync staticfiles/ s3://school-diary-static/static/ \
  --acl public-read \
  --region ap-northeast-1
```

#### 5.3 CloudFront ディストリビューション作成

```bash
# CloudFront ディストリビューション作成
aws cloudfront create-distribution \
  --origin-domain-name school-diary-static.s3.ap-northeast-1.amazonaws.com \
  --default-root-object index.html \
  --enabled \
  --comment "School Diary Static Files" \
  --price-class PriceClass_200 \
  --viewer-certificate ACMCertificateArn=arn:aws:acm:us-east-1:123456789012:certificate/xxxxxx,SSLSupportMethod=sni-only,MinimumProtocolVersion=TLSv1.2_2021

# ディストリビューションURL取得（例: d1234567890.cloudfront.net）
```

---

### Phase 6: ドメイン・SSL 証明書（30 分）

#### 6.1 Route53 ホストゾーン作成

```bash
# ホストゾーン作成（ドメイン購入済みの場合）
aws route53 create-hosted-zone \
  --name school-diary.com \
  --caller-reference $(date +%s)

# NSレコードを取得し、ドメインレジストラに設定
```

#### 6.2 ACM 証明書リクエスト

```bash
# 証明書リクエスト
aws acm request-certificate \
  --domain-name school-diary.com \
  --subject-alternative-names *.school-diary.com \
  --validation-method DNS \
  --region ap-northeast-1

# 検証用DNSレコード追加（ACMコンソールで確認）
```

#### 6.3 Route53 レコード作成

```bash
# ALBへのAレコード（エイリアス）
aws route53 change-resource-record-sets \
  --hosted-zone-id Z1234567890ABC \
  --change-batch '{
    "Changes": [{
      "Action": "CREATE",
      "ResourceRecordSet": {
        "Name": "school-diary.com",
        "Type": "A",
        "AliasTarget": {
          "HostedZoneId": "Z14GRHDCWA56QT",
          "DNSName": "school-diary-alb-xxxxxx.ap-northeast-1.elb.amazonaws.com",
          "EvaluateTargetHealth": true
        }
      }
    }]
  }'
```

---

## 5. CI/CD パイプライン構築

### 5.1 全体フロー

```
GitLab Push → GitLab CI/CD → Build Docker Image → Push to ECR → Deploy to ECS
```

### 5.2 .gitlab-ci.yml 作成

```yaml
stages:
  - test
  - build
  - deploy

variables:
  AWS_REGION: ap-northeast-1
  ECR_REPOSITORY: 123456789012.dkr.ecr.ap-northeast-1.amazonaws.com/school-diary
  ECS_CLUSTER: school-diary-cluster
  ECS_SERVICE: school-diary-django

# テストステージ
test:
  stage: test
  image: python:3.12
  before_script:
    - pip install uv
    - uv pip install --system -r pyproject.toml
  script:
    - python manage.py check
    - pytest tests/ -v --cov=school_diary
  only:
    - merge_requests
    - main

# ビルドステージ
build:
  stage: build
  image: docker:latest
  services:
    - docker:dind
  before_script:
    - apk add --no-cache aws-cli
    - aws ecr get-login-password --region $AWS_REGION | docker login --username AWS --password-stdin $ECR_REPOSITORY
  script:
    - docker build -f Dockerfile.production -t $ECR_REPOSITORY:$CI_COMMIT_SHA .
    - docker tag $ECR_REPOSITORY:$CI_COMMIT_SHA $ECR_REPOSITORY:latest
    - docker push $ECR_REPOSITORY:$CI_COMMIT_SHA
    - docker push $ECR_REPOSITORY:latest
  only:
    - main

# デプロイステージ
deploy:
  stage: deploy
  image: amazon/aws-cli
  script:
    # 新しいタスク定義登録
    - aws ecs register-task-definition --cli-input-json file://task-definition-django.json
    # サービス更新
    - aws ecs update-service --cluster $ECS_CLUSTER --service $ECS_SERVICE --force-new-deployment
    # デプロイ完了待機
    - aws ecs wait services-stable --cluster $ECS_CLUSTER --services $ECS_SERVICE
  only:
    - main
  when: manual
```

---

## 6. 本番運用設定

### 6.1 環境変数管理（Secrets Manager）

```bash
# データベースURL保存
aws secretsmanager create-secret \
  --name school-diary/database-url \
  --secret-string "postgresql://dbadmin:YourStrongPassword123!@school-diary-db.xxxxxx.ap-northeast-1.rds.amazonaws.com:5432/postgres" \
  --region ap-northeast-1

# SECRET_KEY保存
aws secretsmanager create-secret \
  --name school-diary/secret-key \
  --secret-string "$(python -c 'from django.core.management.utils import get_random_secret_key; print(get_random_secret_key())')" \
  --region ap-northeast-1

# Redis URL保存
aws secretsmanager create-secret \
  --name school-diary/redis-url \
  --secret-string "redis://school-diary-redis.xxxxxx.0001.apne1.cache.amazonaws.com:6379/0" \
  --region ap-northeast-1
```

### 6.2 ログ管理

```bash
# CloudWatch Logsグループ作成
aws logs create-log-group \
  --log-group-name /ecs/school-diary-django \
  --region ap-northeast-1

aws logs create-log-group \
  --log-group-name /ecs/school-diary-celery-worker \
  --region ap-northeast-1

# ログ保持期間設定（30日）
aws logs put-retention-policy \
  --log-group-name /ecs/school-diary-django \
  --retention-in-days 30 \
  --region ap-northeast-1
```

### 6.3 監視・アラート

```bash
# SNSトピック作成
aws sns create-topic \
  --name school-diary-alerts \
  --region ap-northeast-1

# メール通知設定
aws sns subscribe \
  --topic-arn arn:aws:sns:ap-northeast-1:123456789012:school-diary-alerts \
  --protocol email \
  --notification-endpoint your-email@example.com

# CloudWatchアラーム作成（例: ECS CPU使用率）
aws cloudwatch put-metric-alarm \
  --alarm-name school-diary-ecs-cpu-high \
  --alarm-description "ECS CPU usage is high" \
  --metric-name CPUUtilization \
  --namespace AWS/ECS \
  --statistic Average \
  --period 300 \
  --threshold 80 \
  --comparison-operator GreaterThanThreshold \
  --evaluation-periods 2 \
  --dimensions Name=ClusterName,Value=school-diary-cluster Name=ServiceName,Value=school-diary-django \
  --alarm-actions arn:aws:sns:ap-northeast-1:123456789012:school-diary-alerts \
  --region ap-northeast-1
```

### 6.4 バックアップ設定

```bash
# RDS自動バックアップ（既に有効）
# 保持期間: 7日

# S3バケットバージョニング有効化
aws s3api put-bucket-versioning \
  --bucket school-diary-static \
  --versioning-configuration Status=Enabled

# RDSスナップショット作成（手動）
aws rds create-db-snapshot \
  --db-instance-identifier school-diary-db \
  --db-snapshot-identifier school-diary-db-snapshot-$(date +%Y%m%d) \
  --region ap-northeast-1
```

---

## 7. コスト試算

### 7.1 開発環境（最小構成）

| サービス                | スペック                              | 月額料金        |
| ----------------------- | ------------------------------------- | --------------- |
| **ECS Fargate**         | 0.25 vCPU, 0.5GB × 2 タスク（Django） | $15             |
| **ECS Fargate**         | 0.25 vCPU, 0.5GB × 1 タスク（Celery） | $7.5            |
| **RDS (PostgreSQL)**    | db.t3.micro (Single-AZ)               | $15             |
| **ElastiCache (Redis)** | cache.t3.micro                        | $12             |
| **ALB**                 | 固定料金 + データ転送                 | $20             |
| **S3**                  | 10GB（静的ファイル）                  | $0.23           |
| **CloudFront**          | 100GB 転送                            | $8.5            |
| **Route53**             | ホストゾーン 1 つ                     | $0.5            |
| **合計**                |                                       | **約$78.73/月** |

### 7.2 本番環境（推奨構成）

| サービス                | スペック                              | 月額料金         |
| ----------------------- | ------------------------------------- | ---------------- |
| **ECS Fargate**         | 0.5 vCPU, 1GB × 2 タスク（Django）    | $30              |
| **ECS Fargate**         | 0.25 vCPU, 0.5GB × 2 タスク（Celery） | $15              |
| **RDS (PostgreSQL)**    | db.t3.small (Multi-AZ)                | $60              |
| **ElastiCache (Redis)** | cache.t3.small (レプリケーション)     | $50              |
| **ALB**                 | 固定料金 + データ転送                 | $35              |
| **S3**                  | 50GB（静的ファイル + メディア）       | $1.15            |
| **CloudFront**          | 500GB 転送                            | $42.5            |
| **Route53**             | ホストゾーン 1 つ                     | $0.5             |
| **Secrets Manager**     | 3 シークレット                        | $1.2             |
| **CloudWatch Logs**     | 5GB/月                                | $2.5             |
| **合計**                |                                       | **約$237.85/月** |

### 7.3 コスト最適化のヒント

- ✅ **開発環境は夜間停止**: ECS Desired Count を 0 にする
- ✅ **RDS スナップショットから復元**: 開発環境は毎朝復元
- ✅ **S3 ライフサイクルポリシー**: 古い静的ファイルを削除
- ✅ **CloudFront キャッシュ最適化**: TTL を長くする

---

## 8. トラブルシューティング

### 8.1 ECS タスクが起動しない

**症状**: ECS タスクが PENDING → STOPPED になる

**原因**:

1. Docker イメージが見つからない
2. 環境変数が正しくない
3. セキュリティグループでポートが開いていない
4. サブネットからインターネットに出られない（NAT Gateway 未設定）

**解決方法**:

```bash
# タスクのログを確認
aws ecs describe-tasks \
  --cluster school-diary-cluster \
  --tasks task-id \
  --region ap-northeast-1

# CloudWatch Logsを確認
aws logs tail /ecs/school-diary-django --follow
```

### 8.2 RDS に接続できない

**症状**: `FATAL: password authentication failed`

**原因**:

1. データベース URL が間違っている
2. セキュリティグループでポート 5432 が開いていない
3. RDS がパブリックアクセス不可

**解決方法**:

```bash
# セキュリティグループを確認
aws ec2 describe-security-groups \
  --group-ids sg-xxxxxx \
  --region ap-northeast-1

# ECSタスクから接続テスト
aws ecs execute-command \
  --cluster school-diary-cluster \
  --task task-id \
  --container django \
  --interactive \
  --command "/bin/bash"

# コンテナ内で
psql "postgresql://dbadmin:password@school-diary-db.xxxxxx.ap-northeast-1.rds.amazonaws.com:5432/postgres"
```

### 8.3 静的ファイルが表示されない

**症状**: CSS, JS が 404

**原因**:

1. collectstatic を実行していない
2. S3 バケットポリシーが正しくない
3. CloudFront キャッシュが古い

**解決方法**:

```bash
# collectstatic 再実行
python manage.py collectstatic --noinput

# S3 に再アップロード
aws s3 sync staticfiles/ s3://school-diary-static/static/ \
  --delete \
  --region ap-northeast-1

# CloudFront キャッシュを無効化
aws cloudfront create-invalidation \
  --distribution-id E1234567890ABC \
  --paths "/*"
```

### 8.4 メモリ不足

**症状**: タスクが OOM Killed

**原因**:

1. メモリ設定が小さい
2. アプリケーションがメモリリーク

**解決方法**:

```bash
# タスク定義でメモリを増やす
# memory: 1024 → 2048

# タスク定義を更新
aws ecs register-task-definition \
  --cli-input-json file://task-definition-django.json

# サービスを更新
aws ecs update-service \
  --cluster school-diary-cluster \
  --service school-diary-django \
  --task-definition school-diary-django:2
```

---

## 9. まとめ: Docker → AWS の全体像

### 完全な対応表

| 開発環境（Docker Compose）   | 本番環境（AWS）                           | 作業内容                                                 |
| ---------------------------- | ----------------------------------------- | -------------------------------------------------------- |
| **docker-compose.yml**       | **ECS タスク定義**                        | JSON 形式に変換                                          |
| **Docker イメージ**          | **ECR**                                   | イメージをプッシュ                                       |
| **django コンテナ**          | **ECS Fargate（Django）**                 | タスク定義作成 → サービス作成                            |
| **celeryworker コンテナ**    | **ECS Fargate（Celery Worker）**          | 別タスク定義作成 → サービス作成                          |
| **celerybeat コンテナ**      | **ECS Fargate（Celery Beat）**            | 別タスク定義作成 → サービス作成                          |
| **postgres コンテナ**        | **RDS PostgreSQL**                        | RDS インスタンス作成 → 接続情報を Secrets Manager に保存 |
| **redis コンテナ**           | **ElastiCache Redis**                     | Redis クラスター作成 → 接続情報を Secrets Manager に保存 |
| **localhost:8000**           | **ALB + Route53**                         | ALB 作成 → ドメイン設定 → SSL 証明書                     |
| **volume（postgres_data）**  | **RDS ストレージ**                        | マネージドストレージ（自動バックアップ付き）             |
| **logs（コンソール出力）**   | **CloudWatch Logs**                       | ログドライバー設定                                       |
| **環境変数（.env）**         | **Secrets Manager / SSM Parameter Store** | シークレット作成 → タスク定義で参照                      |
| **静的ファイル（./static）** | **S3 + CloudFront**                       | collectstatic → S3 アップロード → CloudFront 配信        |
| **開発用メール（mailpit）**  | **SES**                                   | SES 設定 → Django 設定変更                               |
| **git push**                 | **CodePipeline + CodeBuild**              | CI/CD パイプライン構築                                   |

---

## 10. 次のアクション

### 今すぐできること

**ステップ 1**: AWS CLI セットアップ（5 分）

```bash
aws configure
aws sts get-caller-identity
```

**ステップ 2**: Terraform/CloudFormation で Infrastructure as Code（推奨）

- 手動作業を自動化
- 環境の再現性を確保

**ステップ 3**: Phase 1 から順番に実施

- Phase 1: Docker イメージ準備（60 分）
- Phase 2: データベース構築（45 分）
- Phase 3: キャッシュ構築（30 分）
- Phase 4: ECS 構築（90 分）
- Phase 5: 静的ファイル・CDN（45 分）
- Phase 6: ドメイン・SSL 証明書（30 分）

**合計時間**: 約 5 時間（Terraform を使えば 2 時間に短縮可能）

---

## 11. 参考リンク

- [AWS ECS 公式ドキュメント](https://docs.aws.amazon.com/ecs/)
- [Django デプロイチェックリスト](https://docs.djangoproject.com/en/5.1/howto/deployment/checklist/)
- [Terraform AWS Provider](https://registry.terraform.io/providers/hashicorp/aws/latest/docs)

---

**作成者**: AI (Claude Code) + hirok
**バージョン**: 1.0.0
**最終更新**: 2025-10-09
**対象**: インフラ経験者、AWS 基礎知識あり
