# 技術的負債トラッキング

> **最終更新**: 2025-10-09
> **目的**: 妥協した実装、やり残しの記録と管理
> **対象**: PM、開発者

---

## 📊 サマリー

| カテゴリ | 件数 | 優先度 | 解消予定Phase |
|---------|------|--------|-------------|
| ダミー実装 | 2 | 高 | MLP-6, MLP-7 |
| リファクタリング | 0 | - | - |
| パフォーマンス改善 | 0 | - | - |
| **合計** | **2** | - | - |

---

## 🔍 詳細リスト

### ダミー実装 #1: DiaryCreateView

**ID**: DEBT-001
**ファイル**: `school_diary/diary/views.py:49`
**作成日**: 2025-10-09 (MLP-5)
**優先度**: 高
**ステータス**: 🔴 未解消

#### 現状コード
```python
class DiaryCreateView(LoginRequiredMixin, TemplateView):
    """連絡帳作成ページ（ダミー）"""
    template_name = "diary/diary_create.html"
```

#### 問題点
1. **機能不足**:
   - フォーム処理がない
   - データ保存機能がない
   - 「🚧 準備中」メッセージを表示するだけ

2. **ユーザー体験**:
   - 「連絡帳を書く」ボタンをクリックしても何もできない
   - 機能があるように見えて実は空

#### 妥協した理由
1. **時間制約**: MLP-5では生徒ダッシュボードの実装が優先
2. **リンク切れ防止**: 404エラーを避けるため最低限のダミーを実装
3. **段階的実装**: MLP-6で本実装を予定（DiaryEntryForm統合）

#### 解消計画

**Phase**: MLP-6（予定1.5時間）

**実装内容**:
1. CreateViewに変更（TemplateView → CreateView）
2. DiaryEntryFormの統合
3. POST処理実装
   ```python
   class DiaryCreateView(LoginRequiredMixin, CreateView):
       model = DiaryEntry
       form_class = DiaryEntryForm
       template_name = "diary/diary_create.html"
       success_url = reverse_lazy("diary:student_dashboard")

       def form_valid(self, form):
           form.instance.student = self.request.user
           return super().form_valid(form)
   ```
4. バリデーション追加（一日一件制約）
5. 成功メッセージ表示

**完了基準**:
- [ ] 実際に連絡帳を作成できる
- [ ] 一日一件制約が機能する
- [ ] 成功時にダッシュボードにリダイレクト
- [ ] エラーメッセージが適切に表示される

#### 影響範囲
- **View**: `school_diary/diary/views.py:49`
- **Template**: `school_diary/templates/diary/diary_create.html`
- **URL**: `/diary/create/`
- **リンク元**: `student_dashboard.html` の「連絡帳を書く」ボタン

#### 関連タスク
- [連絡帳管理システム_100時間タスクリスト.md](連絡帳管理システム_100時間タスクリスト.md) - MLP-6

---

### ダミー実装 #2: DiaryHistoryView

**ID**: DEBT-002
**ファイル**: `school_diary/diary/views.py:55`
**作成日**: 2025-10-09 (MLP-5)
**優先度**: 高
**ステータス**: 🔴 未解消

#### 現状コード
```python
class DiaryHistoryView(LoginRequiredMixin, TemplateView):
    """過去記録閲覧ページ（ダミー）"""
    template_name = "diary/diary_history.html"
```

#### 問題点
1. **機能不足**:
   - 過去の連絡帳を表示する機能がない
   - ページネーションなし
   - 検索・フィルター機能なし

2. **ユーザー体験**:
   - 「過去の記録を見る」リンクをクリックしても何もできない
   - ダッシュボードの最近7件以降を見る方法がない

#### 妥協した理由
1. **時間制約**: MLP-5では最近7件の表示で十分
2. **段階的実装**: まずは直近の履歴表示を優先
3. **リンク切れ防止**: 404エラーを避けるため最低限のダミーを実装

#### 解消計画

**Phase**: MLP-7（予定1.5時間）

**実装内容**:
1. ListViewに変更（TemplateView → ListView）
2. ページネーション実装（10件/ページ）
3. 日付フィルター実装
   ```python
   class DiaryHistoryView(LoginRequiredMixin, ListView):
       model = DiaryEntry
       template_name = "diary/diary_history.html"
       context_object_name = "entries"
       paginate_by = 10

       def get_queryset(self):
           return DiaryEntry.objects.filter(
               student=self.request.user
           ).select_related("read_by").order_by("-entry_date")
   ```
4. 検索フォーム追加（キーワード検索）
5. 既読・未読フィルター

**完了基準**:
- [ ] 過去の全連絡帳を一覧表示できる
- [ ] ページネーションが機能する（10件/ページ）
- [ ] 日付範囲でフィルターできる
- [ ] キーワード検索ができる
- [ ] 既読・未読でフィルターできる

#### 影響範囲
- **View**: `school_diary/diary/views.py:55`
- **Template**: `school_diary/templates/diary/diary_history.html`
- **URL**: `/diary/history/`
- **リンク元**: `student_dashboard.html` の「過去の記録を見る」リンク

#### 関連タスク
- [連絡帳管理システム_100時間タスクリスト.md](連絡帳管理システム_100時間タスクリスト.md) - MLP-7

---

## 📋 技術的負債追加のフォーマット

新しい技術的負債を追加する場合は、以下の形式で記録してください:

```markdown
### [カテゴリ] #X: [タイトル]

**ID**: DEBT-XXX
**ファイル**: [ファイルパス:行番号]
**作成日**: YYYY-MM-DD ([Phase名])
**優先度**: 高/中/低
**ステータス**: 🔴 未解消 / 🟡 進行中 / 🟢 解消済み

#### 現状コード
\`\`\`python
[現在のコード]
\`\`\`

#### 問題点
1. [問題1]
2. [問題2]

#### 妥協した理由
1. [理由1]
2. [理由2]

#### 解消計画
**Phase**: [Phase名]（予定X時間）

**実装内容**:
1. [実装1]
2. [実装2]

**完了基準**:
- [ ] 基準1
- [ ] 基準2

#### 影響範囲
- **View**: [ファイル]
- **Template**: [ファイル]
- ...

#### 関連タスク
- [タスクリスト参照]
```

---

## 🔄 定期レビュー

### レビュータイミング
- Phase完了時（MVP → MLP → MAP → AWS → DOC）
- 新しい技術的負債が追加された時
- 技術的負債が解消された時

### レビュー項目
1. **件数の確認**: 増減を把握
2. **優先度の見直し**: 影響度に応じて再評価
3. **解消計画の更新**: Phase変更に応じて調整
4. **解消済みの削除**: ステータスを🟢に更新後、アーカイブ

### アーカイブ方針
解消済みの技術的負債は、以下のセクションに移動：

```markdown
## 🗄️ 解消済み技術的負債（アーカイブ）

### ダミー実装 #1: DiaryCreateView（解消済み）
- 解消日: YYYY-MM-DD
- 解消Phase: MLP-6
- [詳細は折りたたみ]
```

---

## 📊 技術的負債の健全性指標

### 目標値
- **MVP期間**: 10件以下
- **MLP期間**: 5件以下
- **MAP期間**: 2件以下
- **AWS期間**: 0件（理想）

### 現在の状態
- **合計**: 2件
- **高優先度**: 2件
- **中優先度**: 0件
- **低優先度**: 0件

**評価**: 🟢 健全（目標内）

---

## 📚 関連ドキュメント

- **既知の問題**: [KNOWN_ISSUES.md](KNOWN_ISSUES.md) - エラー・バグ管理
- **タスクリスト**: [連絡帳管理システム_100時間タスクリスト.md](連絡帳管理システム_100時間タスクリスト.md) - 解消タスクの詳細
- **進捗管理**: [PROJECT_STATUS.md](PROJECT_STATUS.md) - 現在地とマイルストーン

---

**作成者**: Claude Code + hirok
**バージョン**: 1.0.0
**作成日**: 2025-10-09
