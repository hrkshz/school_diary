# docs-private ドキュメントマップ

> **最終更新**: 2025-10-09
> **目的**: 60+個のドキュメントから目的のファイルを素早く見つける
> **対象**: AI（Claude Code）、開発者

---

## 🔍 よくある質問（目的別ナビゲーション）

### 初心者向け

- **Q: Web 開発・プログラミング未経験、何から学ぶ？** → [初心者向け学習ロードマップ.md](初心者向け学習ロードマップ.md) ⭐NEW
- **Q: このプロジェクトで何を学べる？** → [初心者向け学習ロードマップ.md](初心者向け学習ロードマップ.md)
- **Q: 一流のエンジニアの思考を学びたい** → [daily_logs/](daily_logs/) の学習ログ

### プロジェクト進行中

- **Q: 今日何をすればいい？** → [PROJECT_STATUS.md](PROJECT_STATUS.md)
- **Q: タスクの詳細手順は？** → [連絡帳管理システム\_100 時間タスクリスト.md](連絡帳管理システム_100時間タスクリスト.md)
- **Q: エラーが出た、対処法は？** → [KNOWN_ISSUES.md](KNOWN_ISSUES.md)
- **Q: 技術的負債を確認したい** → [TECHNICAL_DEBT.md](TECHNICAL_DEBT.md)
- **Q: 変更履歴を確認したい** → [../CHANGELOG.md](../CHANGELOG.md)

### デプロイ・本番環境

- **Q: Docker 環境を AWS にデプロイしたい** → [AWS\_デプロイ戦略.md](AWS_デプロイ戦略.md) ⭐NEW
- **Q: 7 つのコンテナをどう AWS に乗せる？** → [AWS\_デプロイ戦略.md](AWS_デプロイ戦略.md)
- **Q: コストはいくらかかる？** → [AWS\_デプロイ戦略.md](AWS_デプロイ戦略.md) の「コスト試算」セクション

### 新規タスク開始時

- **Q: タスクの進め方は？** → [frameworks/タスク実行プロトコル.md](frameworks/タスク実行プロトコル.md)
- **Q: 完了の基準は？** → [frameworks/品質ゲート定義.md](frameworks/品質ゲート定義.md)
- **Q: 学習ログの書き方は？** → [daily_logs/学習ログテンプレート.md](daily_logs/学習ログテンプレート.md)

### 困った時

- **Q: ブロックされた、どう報告？** → [frameworks/ブロッカー報告テンプレート.md](frameworks/ブロッカー報告テンプレート.md)
- **Q: 過去の間違いから学びたい** → [frameworks/よくある間違い集テンプレート.md](frameworks/よくある間違い集テンプレート.md)
- **Q: セッション開始/終了の手順は？** → [RULES.md](RULES.md)

### 設計判断時

- **Q: 設計判断の記録方法は？** → [frameworks/設計判断記録テンプレート.md](frameworks/設計判断記録テンプレート.md)
- **Q: 5 段階理解モデルとは？** → [frameworks/5 段階理解モデル.md](frameworks/5段階理解モデル.md)

---

## 📂 カテゴリ別ドキュメント一覧

### 📍 スタートガイド（最初に読む）

1. [START_HERE.md](START_HERE.md) - プロジェクト初見者向けガイド
2. [PROJECT_STATUS.md](PROJECT_STATUS.md) - 現在地とタスク状況（SSOT）
3. [RULES.md](RULES.md) - セッション開始/終了プロトコル
4. [初心者向け学習ロードマップ.md](初心者向け学習ロードマップ.md) - Web 開発未経験者向けの体系的学習パス ⭐NEW

### 🎯 プロジェクト管理

- [PROJECT_STATUS.md](PROJECT_STATUS.md) - 進捗管理（SSOT）
- [連絡帳管理システム\_100 時間タスクリスト.md](連絡帳管理システム_100時間タスクリスト.md) - 全 51 タスク詳細
- [連絡帳管理システム\_実装戦略.md](連絡帳管理システム_実装戦略.md) - 実装戦略
- [../CHANGELOG.md](../CHANGELOG.md) - 変更履歴（外部向け）

### 🔧 品質管理

- [KNOWN_ISSUES.md](KNOWN_ISSUES.md) - 既知の問題・エラー管理
- [TECHNICAL_DEBT.md](TECHNICAL_DEBT.md) - 技術的負債トラッキング

### 📚 フレームワーク（Learning-Driven Development）

- [frameworks/README.md](frameworks/README.md) - フレームワーク全体像
- [frameworks/タスク実行プロトコル.md](frameworks/タスク実行プロトコル.md) - 4 フェーズ標準手順
- [frameworks/品質ゲート定義.md](frameworks/品質ゲート定義.md) - 完了基準
- [frameworks/5 段階理解モデル.md](frameworks/5段階理解モデル.md) - 学習深度定義
- [frameworks/設計判断記録テンプレート.md](frameworks/設計判断記録テンプレート.md) - 判断記録方法
- [frameworks/よくある間違い集テンプレート.md](frameworks/よくある間違い集テンプレート.md) - 失敗記録方法
- [frameworks/レビューチェックリスト.md](frameworks/レビューチェックリスト.md) - ユーザー向けレビュー基準
- [frameworks/ブロッカー報告テンプレート.md](frameworks/ブロッカー報告テンプレート.md) - 問題報告方法
- [frameworks/教育資料作成ルール.md](frameworks/教育資料作成ルール.md) - 教育資料作成ガイド

### 📝 学習ログ（日次記録）

- [daily_logs/学習ログテンプレート.md](daily_logs/学習ログテンプレート.md) - テンプレート
- [daily*logs/20251006_day1*学習ログ.md](daily_logs/20251006_day1_学習ログ.md) - Day 1
- [daily*logs/20251007_day2*学習ログ.md](daily_logs/20251007_day2_学習ログ.md) - Day 2
- [daily*logs/20251008_day5*学習ログ.md](daily_logs/20251008_day5_学習ログ.md) - Day 5
- [daily*logs/20251009_day6*学習ログ.md](daily_logs/20251009_day6_学習ログ.md) - Day 6（最新）

### 📐 システム設計

- [要件定義書.md](要件定義書.md) - Challenge 1 + 2 の構造化
- [データモデル設計書.md](データモデル設計書.md) - ER 図、テーブル定義
- [機能仕様書.md](機能仕様書.md) - ユースケース、画面遷移、ワイヤーフレーム
- [システムアーキテクチャ設計書.md](システムアーキテクチャ設計書.md) - 技術スタック、デプロイ戦略
- [テスト計画書.md](テスト計画書.md) - テストアカウント、12 シナリオ
- [AWS\_デプロイ戦略.md](AWS_デプロイ戦略.md) - Docker → AWS 完全移行ガイド ⭐NEW

### 🗄️ アーカイブ（参考資料）

- [archive/](archive/) - 古いドキュメント、廃止された戦略

---

## 🔄 ドキュメント間の関係

```
START_HERE.md （入り口）
    ↓
PROJECT_STATUS.md （現在地）
    ↓
連絡帳管理システム_100時間タスクリスト.md （次のタスク）
    ↓
frameworks/タスク実行プロトコル.md （実行方法）
    ↓
daily_logs/YYYYMMDD_*.md （学習記録）
    ↓
frameworks/品質ゲート定義.md （完了確認）
    ↓
PROJECT_STATUS.md （進捗更新）
```

**品質管理のフロー**:

```
エラー発生
    ↓
KNOWN_ISSUES.md （既知の問題か確認）
    ↓
frameworks/よくある間違い集テンプレート.md （過去の解決例）
    ↓
frameworks/ブロッカー報告テンプレート.md （解決できない場合）
```

**技術的負債の管理**:

```
妥協実装（ダミー等）
    ↓
TECHNICAL_DEBT.md （記録）
    ↓
連絡帳管理システム_100時間タスクリスト.md （解消タスクを確認）
    ↓
解消実装
    ↓
TECHNICAL_DEBT.md （ステータス更新）
```

---

## 📝 このドキュメントの使い方

### AI の場合

1. **タスク開始時**: 「Q: タスクの進め方は？」からプロトコルを確認
2. **エラー発生時**: 「Q: エラーが出た」から KNOWN_ISSUES を確認
3. **判断が必要な時**: 「Q: 設計判断の記録方法は？」からテンプレートを確認

### 人間の場合

1. **プロジェクト参加時**: まず「スタートガイド」を読む
2. **日次作業開始時**: PROJECT_STATUS.md で現在地を確認
3. **レビュー時**: frameworks/レビューチェックリスト.md を使用

### ドキュメントが見つからない場合

1. まず「よくある質問」で探す
2. 見つからない場合は「カテゴリ別一覧」から探す
3. それでも見つからない場合は PROJECT_STATUS.md の「関連ドキュメント」セクションを確認
4. 全て試してもない場合は、新規作成を検討

---

## 🔍 検索のヒント

**キーワード検索**:

```bash
# docs-private 内を検索
grep -r "キーワード" /home/hirok/work/school_diary/docs-private/

# タスクリストを検索
grep "MLP-" docs-private/連絡帳管理システム_100時間タスクリスト.md
```

**最近更新されたファイル**:

```bash
find /home/hirok/work/school_diary/docs-private/ -name "*.md" -mtime -7 | sort
```

---

**作成者**: Claude Code + hirok
**バージョン**: 1.0.0
**最終更新**: 2025-10-09
