# 既知の問題リスト

> **最終更新**: 2025-10-09
> **目的**: 許容したエラー・問題の記録と管理
> **対象**: PM、開発者

---

## 📊 サマリー

| カテゴリ | 件数 | 影響度 | 対応予定Phase |
|---------|------|--------|-------------|
| Ruff: 日本語文字警告 | 48 | 低 | MAP完了後 |
| Ruff: 長い行 | 3 | 低 | リファクタ時 |
| **合計** | **51** | - | - |

---

## 🔍 詳細リスト

### カテゴリ1: Ruff - 日本語文字警告（RUF001/002/003）

**件数**: 48件
**影響度**: 低
**最終確認日**: 2025-10-09 (MLP-5完了時)

#### 許容理由
1. **プロジェクトの性質**: 日本語UIアプリケーション
   - docstringや変数名に日本語が必須
   - 可読性とメンテナンス性を優先
2. **セキュリティリスク**: なし
   - 全角文字の誤認識による脆弱性は、本プロジェクトでは該当しない
3. **開発効率**: 日本語を使うことで理解が早まる
   - 初心者向け教育資料としての価値

#### 対応計画
- **Phase**: MAP完了後（Phase 3）
- **方法1**: `# noqa: RUF001` コメントで明示的に許可
- **方法2**: `ruff.toml` で日本語を許可
  ```toml
  [lint]
  ignore = ["RUF001", "RUF002", "RUF003"]
  ```
- **判断基準**: 時間があればnoqa追加、なければruff.toml設定

#### エラー例
```
school_diary/diary/models.py:15:9: RUF001 String contains ambiguous `（` (FULLWIDTH LEFT PARENTHESIS). Did you mean `(` (LEFT PARENTHESIS)?
school_diary/diary/admin.py:23:17: RUF002 Docstring contains ambiguous `：` (FULLWIDTH COLON). Did you mean `:` (COLON)?
school_diary/diary/views.py:12:9: RUF003 Comment contains ambiguous `　` (IDEOGRAPHIC SPACE). Did you mean ` ` (SPACE)?
```

#### 影響範囲（ファイル別件数）
- `school_diary/diary/models.py`: 12件
- `school_diary/diary/admin.py`: 8件
- `school_diary/diary/views.py`: 6件
- `school_diary/diary/forms.py`: 4件
- `school_diary/templates/diary/*.html`: 10件（コメント内）
- その他: 8件

#### ステータス
- [x] 問題を特定
- [x] 許容理由を文書化
- [ ] ruff.toml設定（MAP Phase）
- [ ] または noqa コメント追加（MAP Phase）

---

### カテゴリ2: Ruff - 長い行（E501）

**件数**: 3件
**影響度**: 低
**最終確認日**: 2025-10-09 (MLP-5完了時)

#### 許容理由
1. **Django設定の長いURL**: 改行すると可読性が下がる
2. **インポート文の長さ**: 自動生成のため、手動改行は非効率
3. **88文字制限の厳しさ**: Ruffのデフォルト設定が厳しい
   - Black（Pythonフォーマッター）は88文字を推奨
   - しかし、URL等は例外とすべき

#### 対応計画
- **Phase**: リファクタリング時（Phase 3以降）
- **方法1**: 適切に改行（可読性を損なわない範囲）
- **方法2**: `# noqa: E501` で許可
- **方法3**: ruff.tomlで行長を緩和（例: 100文字）

#### エラー例
```
config/settings/base.py:42:89: E501 Line too long (102 > 88)
school_diary/diary/urls.py:15:89: E501 Line too long (95 > 88)
school_diary/config/urls.py:8:89: E501 Line too long (110 > 88)
```

#### 詳細
1. **config/settings/base.py:42** (102文字)
   ```python
   # 長いURL設定
   ALLOWED_HOSTS = ["localhost", "127.0.0.1", "school-diary.example.com", "school-diary-staging.example.com"]
   ```
   - 理由: 複数ホストを1行で管理

2. **school_diary/diary/urls.py:15** (95文字)
   ```python
   path("student/dashboard/", views.StudentDashboardView.as_view(), name="student_dashboard"),
   ```
   - 理由: Django URLパターンの標準形式

3. **school_diary/config/urls.py:8** (110文字)
   ```python
   path("admin/", admin.site.urls),  # Django管理画面（jazzminでモダンUIに変更済み）
   ```
   - 理由: コメント付きURL設定

#### ステータス
- [x] 問題を特定
- [x] 許容理由を文書化
- [ ] 改行またはnoqa追加（Phase 3以降）

---

## 📋 問題追加のフォーマット

新しい既知の問題を追加する場合は、以下の形式で記録してください:

```markdown
### カテゴリX: [問題の種類]

**件数**: X件
**影響度**: 高/中/低
**最終確認日**: YYYY-MM-DD

#### 許容理由
1. [理由1]
2. [理由2]

#### 対応計画
- **Phase**: [いつ対応するか]
- **方法**: [どう対応するか]

#### エラー例
\`\`\`
[エラーメッセージ]
\`\`\`

#### ステータス
- [ ] 問題を特定
- [ ] 許容理由を文書化
- [ ] 対応実施
```

---

## 🔄 定期レビュー

### レビュータイミング
- Phase完了時（MVP → MLP → MAP → AWS → DOC）
- 新しいエラーが10件以上追加された時
- ユーザーからのフィードバック時

### レビュー項目
1. 件数の変化（増減）
2. 影響度の再評価
3. 対応計画の見直し
4. 解消された問題の削除

---

## 📚 関連ドキュメント

- **技術的負債**: [TECHNICAL_DEBT.md](TECHNICAL_DEBT.md) - ダミー実装等の管理
- **間違い記録**: [frameworks/よくある間違い集テンプレート.md](frameworks/よくある間違い集テンプレート.md) - 解決済みの問題
- **ブロッカー報告**: [frameworks/ブロッカー報告テンプレート.md](frameworks/ブロッカー報告テンプレート.md) - 進行中の問題

---

**作成者**: Claude Code + hirok
**バージョン**: 1.0.0
**作成日**: 2025-10-09
