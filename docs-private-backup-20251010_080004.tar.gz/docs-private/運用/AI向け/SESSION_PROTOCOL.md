---
tags: [AI向け, 運用, 現行, 高重要度]
target: AI（Claude Code）
purpose: セッション開始・終了の詳細手順
last_updated: 2025-10-08
status: 現行
phase: 全Phase
---

# セッション開始・終了プロトコル詳細

> **対象読者**: AI（Claude Code）向け
> **用途**: 詳細マニュアル（セッション処理の完全な手順）
> **要約版**: @docs-private/運用/AI向け/RULES.md
> **目的**: セッションの開始と終了を標準化し、確実に状態を保存・復元する
>
> **📝 ドキュメント依存関係**:
> このドキュメントを更新した場合、以下も確認してください:
> - @docs-private/運用/AI向け/RULES.md（要約版を更新）
> - @CLAUDE.md（参照が正しいか確認）
> - @docs-private/フレームワーク/タスク実行プロトコル.md（Phase手順との整合性確認）

---

## 🚀 セッション開始プロトコル

### ユーザーの操作
```
「再開」または「続ける」
```

### AIの自動処理（4ステップ）

#### Step 1: @PROJECT_STATUS.md を読む
```bash
Read @docs-private/運用/AI向け/PROJECT_STATUS.md
```

取得する情報:
- 現在のPhase（MVP/MLP/MAP/AWS/DOC）
- 累計作業時間
- タスクグループ状態
- 今日の目標

#### Step 2: TodoWriteの状態確認
Todoリストから現在の進捗を確認:
- in_progress のタスクグループ
- pending のタスクグループ
- completed のタスクグループ

#### Step 3: 状況サマリー作成
```
現在地:
- Phase: MVP (1/5)
- 累計時間: 3時間 / 11時間
- 進捗: 基盤構築グループ完了、モデル実装グループ進行中
- 次のタスク: MVP-4（DiaryEntry実装）
```

#### Step 4: 次タスクの提案
```
MVP-4（DiaryEntry実装）を実行しますか？
```

**注**: Memory MCPは読まない（PROJECT_STATUS.mdがSSOT）

---

## 🛑 セッション終了プロトコル

### ユーザーの操作
```
「今日はここまで」または「終了」または「セッション終了」
```

### AIの自動処理（4ステップ）

#### Step 1: 今日のサマリー作成
```markdown
## 今日の作業サマリー

### 完了タスク
- MVP-1: プロジェクト初期化（実績30分、予定30分）✅
- MVP-2: アプリ作成（実績20分、予定15分）✅
- MVP-3: ER図作成（実績1.5h、予定1h）⚠️ 30分超過

### 作業時間
- 実績: 3時間
- 予定: 2.75時間
- 差分: +15分

### 進捗
- タスクグループ: 基盤構築（MVP-1〜3）完了 ✅
- 次回: モデル実装グループ（MVP-4〜6）開始

### 発見した問題
- なし

### 学んだこと
- dbdiagram.ioが非常に便利
- create_project.shが完璧に動作
```

#### Step 2: @PROJECT_STATUS.md 更新
```bash
Edit @docs-private/運用/AI向け/PROJECT_STATUS.md
```

更新内容:
1. **最終更新日時**を現在時刻に変更
2. **累計作業時間**を更新（3時間 / 11時間）
3. **タスクグループ進捗**を更新
   - 基盤構築: pending → completed
   - モデル実装: pending → in_progress（次回開始予定）
4. **今日の目標**を次回の目標に更新
5. **最近の更新履歴**に今日のサマリーを追加

#### Step 3: 日次ログ作成（日付自動取得）

**日付取得**（必須）:
```bash
# 1. 日付を取得
TODAY=$(date +%Y%m%d)

# 2. システムメッセージと照合
# システムメッセージの「Today's date」と一致することを確認
echo "今日の日付: $TODAY"

# 3. ファイル作成
touch /home/hirok/work/school_diary/docs-private/daily_logs/${TODAY}_dayN_学習ログ.md
```

**テンプレート**:
```markdown
# Day N - YYYY-MM-DD

## 概要
**Phase**: MVP
**作業時間**: 10:00-13:00 (合計3h)
**完了タスク**: MVP-1, MVP-2, MVP-3

## タスク詳細

### MVP-1: プロジェクト初期化 ✅
**時間**: 30分（予定30分）
**実施内容**:
- create_project.sh 実行成功
- crispy-forms確認済み
- Git初期化完了

**確認項目**:
- [x] school_diaryディレクトリ作成
- [x] Django設定ファイル存在
- [x] Git初期化完了

**問題**: なし

---

### MVP-2: アプリ作成 ✅
...

---

## 発見した問題と解決策
1. 問題: xxx
   解決: yyy

## 学んだこと
- dbdiagram.ioが便利
- create_project.shが完璧

## 明日の予定
- MVP-4〜6: モデル実装完了目標
```

#### Step 4: Git commit
```bash
git add /home/hirok/work/school_diary/docs-private/PROJECT_STATUS.md
git add /home/hirok/work/school_diary/docs-private/daily_logs/YYYYMMDD_dayN.md
git commit -m "progress: Day N完了 - 基盤構築グループ完了

累計時間: 3h / 11h (MVP)
完了タスク: MVP-1, MVP-2, MVP-3
完了グループ: 基盤構築
次回: モデル実装グループ開始（MVP-4）"
```

**注**: 通常のセッション終了時はMemory MCP更新なし

---

## 💾 Memory MCP活用方針（改訂版）

### 基本原則

**Memory MCPは「長期的な知識資産」として活用**

- ✅ **プロジェクト完了時の成果記録**（年2-3回程度）
- ✅ **技術選定の判断理由**（将来のプロジェクトで参考）
- ✅ **時間節約テクニック**（再利用可能なノウハウ）
- ✅ **重大な失敗と教訓**（同じ過ちを防ぐ）
- ❌ **日々のタスク進捗**（→ PROJECT_STATUS.md）
- ❌ **次回タスク**（→ PROJECT_STATUS.md）
- ❌ **詳細な実装内容**（→ daily_logs/）

### Memory MCPとPROJECT_STATUS.mdの役割分担

| 情報種別 | PROJECT_STATUS.md | Memory MCP | 理由 |
|---------|------------------|------------|------|
| 現在地（Phase、累計時間） | ✅ | ❌ | 高速読み取り、SSOT |
| 次回タスク | ✅ | ❌ | セッション開始時に必要 |
| タスク進捗 | ✅ | ❌ | リアルタイムに変化 |
| Phase完了記録 | ✅ (phase_reports/) | ❌ | Git tagで管理 |
| 技術選定理由 | ❌ | ✅ | 長期的な知見 |
| 時間節約テクニック | ❌ | ✅ | 他プロジェクトで再利用 |
| プロジェクト最終成果 | ❌ | ✅ | 将来の参考 |

**原則**: SSOT（Single Source of Truth）を維持
- 同じ情報を複数箇所に記録しない
- 現在地はPROJECT_STATUS.mdのみ
- 長期的知見はMemory MCPのみ

---

## 📊 Memory MCP更新タイミング

### プロジェクト完了時（年2-3回程度）

**タイミング**: 連絡帳管理システム完了時（Day 5最終日）

**更新内容**:
```python
# 1. labapp全体の知見に追加
mcp__memory__add_observations({
    "observations": [{
        "entityName": "labapp_architecture",
        "contents": [
            "連絡帳管理システムでcrispy-forms活用成功（2025-10-10）",
            "12時間節約達成、フォーム実装が2-3倍高速化"
        ]
    }, {
        "entityName": "time_saving_techniques",
        "contents": [
            "crispy-forms活用: Django標準フォームをBootstrap5で自動スタイリング",
            "AdminLTE不採用判断: 要件に合わない場合は避ける（学習コスト大）",
            "DemoRequestパターン: 類似モデルのコピー&修正で高速実装"
        ]
    }, {
        "entityName": "django_patterns",
        "contents": [
            "連絡帳管理システム実装パターン: DiaryEntry（DemoRequest基盤）+ 既読管理",
            "unique_together使用時の注意: マイグレーションエラーに注意"
        ]
    }]
})

# 2. プロジェクト完了記録を作成
mcp__memory__create_entities({
    "entities": [{
        "name": "school_diary_project",
        "entityType": "completed_project",
        "observations": [
            "2025-10-06開始、2025-10-10完了（5日間）",
            "実績98時間 / 目標100時間",
            "最終評価: 95点（目標達成）",
            "技術スタック: Django 5.1.12 + PostgreSQL + crispy-forms + Bootstrap5",
            "主要機能: 連絡帳登録、既読処理、体調推移グラフ、提出漏れ通知"
        ]
    }]
})
```

### 重大な技術選定時（プロジェクト開始時に1回）

**タイミング**: crispy-forms採用決定時（既に完了）

**更新内容**:
```python
mcp__memory__add_observations({
    "observations": [{
        "entityName": "labapp_architecture",
        "contents": [
            "2025-10-06: crispy-forms採用決定（AdminLTE不採用）",
            "理由: 12時間節約、要件適合、labapp既存導入済み"
        ]
    }]
})
```

### 重大な失敗時（発生時のみ）

**タイミング**: 数時間以上の問題に直面した場合

**例**:
```python
mcp__memory__add_observations({
    "observations": [{
        "entityName": "common_pitfalls",
        "contents": [
            "2025-10-XX: unique_togetherマイグレーションエラー",
            "問題: 既存データがある状態でunique_together追加 → エラー",
            "解決: makemigrations --empty で手動マイグレーション",
            "教訓: unique_together変更時は既存データ確認必須"
        ]
    }]
})
```

---

## ❌ Memory MCPに記録しない情報

### 1. タスク進捗（PROJECT_STATUS.mdで管理）
```
❌ 悪い例:
"MVP-1完了"
"MVP-2完了"
"次回: MVP-4から開始"

✅ 正しい管理方法:
PROJECT_STATUS.md の「タスクグループ進捗」セクション
```

### 2. Phase完了記録（Git tagとphase_reports/で管理）
```
❌ 悪い例:
"MVP Phase完了（2025-10-07）"

✅ 正しい管理方法:
- Git tag: v0.1.0-mvp
- phase_reports/mvp_completed.md
```

### 3. 実装詳細（daily_logs/とソースコードで管理）
```
❌ 悪い例:
"DiaryEntryモデルにhealth_conditionフィールドを追加"

✅ 正しい管理方法:
daily_logs/20251007_day2.md
```

---

## 📋 セッション終了チェックリスト

### 通常のセッション終了時

- [ ] **Step 1**: 今日のサマリー作成
- [ ] **Step 2**: PROJECT_STATUS.md 更新
- [ ] **Step 3**: 日次ログ作成
- [ ] **Step 4**: Git commit

**Memory MCPは更新しない**

### プロジェクト完了時のみ

上記に加えて:
- [ ] **Step 5**: phase_reports/final_report.md 作成
- [ ] **Step 6**: Git tag作成（v1.0.0-production）
- [ ] **Step 7**: Memory MCP更新（最終成果、技術選定理由、教訓）

---

## 💡 実行例

### 例1: 通常のセッション終了（Day 1〜Day 4）

```
ユーザー: 「今日はここまで」

AI:
1. 今日のサマリー作成 ✅
   - 完了: MVP-1, MVP-2, MVP-3
   - 時間: 3時間

2. PROJECT_STATUS.md 更新 ✅
   - 累計時間: 3h / 11h
   - 基盤構築: completed
   - モデル実装: pending → in_progress（次回）

3. 日次ログ作成 ✅
   - daily_logs/20251006_day1.md

4. Git commit ✅
   - コミットメッセージ: "progress: Day 1完了..."

セッション終了処理完了。
次回「再開」で続きから開始できます。
```

### 例2: プロジェクト完了時（Day 5最終日）

```
ユーザー: 「今日はここまで」

AI:
1. 今日のサマリー作成 ✅
   - 完了: DOC-8（最終ドキュメント作成）
   - 時間: 3時間
   - **プロジェクト完了！**

2. PROJECT_STATUS.md 更新 ✅
   - 現在Phase: DOC → 完了
   - 累計時間: 98h / 100h

3. 最終レポート作成 ✅
   - phase_reports/final_report.md
   - スクリーンショット、評価サマリー

4. Git tag作成 ✅
   - v1.0.0-production

5. Git commit ✅

6. Memory MCP更新（プロジェクト完了） ✅
   - labapp_architectureに成功事例追加
   - time_saving_techniquesにcrispy-forms活用ノウハウ追加
   - school_diary_project作成（最終成果記録）

プロジェクト完了おめでとうございます！
最終評価: 95点（目標達成）
```

---

## 🎯 まとめ

### セッション開始（毎回）
```
ユーザー: 「再開」
AI: PROJECT_STATUS.md読む（Memory MCPは読まない）→ 次タスク提案
```

### セッション終了（毎回）
```
ユーザー: 「今日はここまで」
AI: 4ステップ処理（サマリー、PROJECT_STATUS.md、daily_logs、commit）
Memory MCPは更新しない
```

### プロジェクト完了時（年2-3回）
```
上記に加えて:
- 最終レポート作成
- Git tag作成
- Memory MCP更新（知見の蓄積）
```

### Memory MCPの役割
```
日常的な進捗管理: PROJECT_STATUS.md（SSOT）
長期的な知見蓄積: Memory MCP（プロジェクト完了時）
```

---

**作成日**: 2025-10-06
**バージョン**: 2.0.0（Memory MCP活用方針改訂）
**目的**: シンプルで効率的なセッション管理

